if CLIENT then
SWEP.WepSelectIcon = surface.GetTextureID( "cod4/vgui/weapons/deserteaglegold_selecticon" )
SWEP.DrawWeaponInfoBox	= false
SWEP.BounceWeaponIcon = false
killicon.Add( "weapon_cod4_deserteaglegold", "cod4/vgui/weapons/deserteagle_killicon", Color( 255, 255, 255, 255 ) )
end

SWEP.PrintName = "Gold Desert Eagle"
SWEP.Category = "Call of Duty 4: Modern Warfare"
SWEP.Spawnable = true
SWEP.AdminSpawnable = true
SWEP.AdminOnly = true

SWEP.ViewModelFOV = 70
SWEP.ViewModel = "models/cod4/weapons/v_deserteaglegold.mdl"
SWEP.WorldModel = "models/cod4/weapons/w_deserteaglegold.mdl"
SWEP.ViewModelFlip = false
SWEP.BobScale = 0
SWEP.SwayScale = 0.5

SWEP.AutoSwitchTo = false
SWEP.AutoSwitchFrom = false
SWEP.Weight = 5
SWEP.Slot = 1
SWEP.SlotPos = 0

SWEP.UseHands = false
SWEP.HoldType = "pistol"
SWEP.HoldTypeSprint = "normal"
SWEP.FiresUnderwater = true
SWEP.DrawCrosshair = false
SWEP.DrawAmmo = true
SWEP.CSMuzzleFlashes = 1
SWEP.Base = "weapon_base"

SWEP.Iron = 0
SWEP.Reloading = 0
SWEP.ReloadingTimer = CurTime()
SWEP.ReloadingTime = 1.3
SWEP.ReloadingEmptyTime = 1.7
SWEP.Holstering = 0
SWEP.HolsteringTimer = CurTime()
SWEP.HolsteringWeapon = 0
SWEP.Sprint = 0
SWEP.BobX = 0
SWEP.BobDirectionX = 0
SWEP.BobY = 0
SWEP.BobDirectionY = 0
SWEP.Idle = 0
SWEP.IdleTimer = CurTime()

SWEP.Primary.Sound = Sound( "Weapon_CoD4_DesertEagle.Single" )
SWEP.Primary.ClipSize = 7
SWEP.Primary.DefaultClip = 21
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "Pistol"
SWEP.Primary.Damage = 50
SWEP.Primary.TakeAmmo = 1
SWEP.Primary.Penetration = 16
SWEP.Primary.PenetrationModifier = 0.5
SWEP.Primary.Spread = 0.001
SWEP.Primary.SpreadMin = 0.001
SWEP.Primary.SpreadKick = 0.04
SWEP.Primary.SpreadKickIron = 0.02
SWEP.Primary.SpreadMax = 0.08
SWEP.Primary.SpreadTimer = CurTime()
SWEP.Primary.SpreadTime = 2
SWEP.Primary.NumberofShots = 1
SWEP.Primary.Delay = 0.05
SWEP.Primary.Force = 10

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = true
SWEP.Secondary.Ammo = "none"

function SWEP:Initialize()
self.Weapon:SetWeaponHoldType( self.HoldType )
self.Idle = 0
self.IdleTimer = CurTime() + 2
end

function SWEP:GetViewModelPosition( pos, ang )
if self.Owner:IsOnGround() and self.Weapon:GetNWBool( "Crosshair" ) == true then
if !self.Owner:KeyDown( IN_ATTACK2 ) and self.Sprint == 0 then
if self.Owner:GetVelocity():Length() < 250 then
pos = pos + ( ang:Right() * math.sin( self.BobX ) * 0.125 + ang:Up() * math.sin( self.BobY ) * 0.125 ) * self.Owner:GetVelocity():Length() / 200
end
if self.Owner:GetVelocity():Length() >= 250 then
pos = pos + ang:Right() * math.sin( self.BobX ) * 0.125 + ang:Up() * math.cos( self.BobY ) * 0.125
end
end
if self.Owner:GetVelocity():Length() < 250 then
pos = pos - ang:Up() * self.Owner:GetVelocity():Length() / 200 - ang:Right() * self.Owner:GetVelocity():Length() / 400
end
if self.Owner:GetVelocity():Length() >= 250 then
pos = pos - ang:Up() - ang:Right()
end
end
return pos, ang
end

function SWEP:CalcView( ply, pos, ang, fov )
local attachment = self.Owner:GetViewModel():GetAttachment( self.Owner:GetViewModel():LookupAttachment( "camera" ) )
ang = ang + Angle( self.Owner:GetViewModel():WorldToLocalAngles( attachment.Ang ).x, self.Owner:GetViewModel():WorldToLocalAngles( attachment.Ang ).y, self.Owner:GetViewModel():WorldToLocalAngles( attachment.Ang ).z )
if self.Owner:IsOnGround() then
if self.Owner:GetVelocity():Length() < 250 then
ang = ang + Angle( math.sin( self.BobY * 0.75 ) * 0.25 * self.Owner:GetVelocity():Length() / 200, math.cos( self.BobX * 0.75 ) * 0.25 * self.Owner:GetVelocity():Length() / 200, 0 )
end
if self.Owner:GetVelocity():Length() >= 250 then
ang = ang + Angle( math.sin( self.BobY * 0.75 ) * 0.5, math.cos( self.BobX * 0.75 ) * 0.5, 0 )
end
end
return pos, ang
end

function SWEP:DrawHUD()
local dist = self.Primary.Spread / self.Primary.SpreadMax * 20 + 30
surface.SetTexture( surface.GetTextureID( "cod4/vgui/side_small" ) )
if self.Weapon:GetNWBool( "Crosshair" ) == true then
surface.SetDrawColor( GetConVar( "cod4_crosshair_red" ):GetInt(), GetConVar( "cod4_crosshair_green" ):GetInt(), GetConVar( "cod4_crosshair_blue" ):GetInt(), GetConVar( "cod4_crosshair_alpha" ):GetInt() )
end
if self.Weapon:GetNWBool( "Crosshair" ) == false then
surface.SetDrawColor( 0, 0, 0, 0 )
end
surface.DrawTexturedRectRotated( ScrW() / 2 - dist, ScrH() / 2, 12, 12, 90 )
surface.DrawTexturedRectRotated( ScrW() / 2 + dist, ScrH() / 2, 12, 12, -90 )
surface.DrawTexturedRectRotated( ScrW() / 2, ScrH() / 2 - dist, 12, 12, 0 )
surface.DrawTexturedRectRotated( ScrW() / 2, ScrH() / 2 + dist, 12, 12, 180 )
end

function SWEP:Deploy()
self.Weapon:SetWeaponHoldType( self.HoldType )
self.Weapon:SendWeaponAnim( ACT_VM_DRAW )
self.Weapon:SetNextPrimaryFire( CurTime() + self.Owner:GetViewModel():SequenceDuration() )
self.Weapon:SetNextSecondaryFire( CurTime() + self.Owner:GetViewModel():SequenceDuration() )
self.Iron = 0
self.Reloading = 0
self.ReloadingTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
self.Holstering = 0
self.HolsteringTimer = CurTime()
self.HolsteringWeapon = 0
self.Sprint = 0
self.BobX = 0
self.BobDirectionX = 0
self.BobY = 0
self.BobDirectionY = 0
self.Idle = 0
self.IdleTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
self.Owner:SetWalkSpeed( 200 )
self.Weapon:SetNWBool( "Crosshair", true )
self.Weapon:SetNWBool( "Holster", false )
return true
end

function SWEP:Holster( wep )
if IsValid( wep ) and self.Weapon:GetNWBool( "Holster" ) == false then
self.Weapon:SendWeaponAnim( ACT_VM_HOLSTER )
self.Weapon:SetNextPrimaryFire( CurTime() + self.Owner:GetViewModel():SequenceDuration() * 2 )
self.Weapon:SetNextSecondaryFire( CurTime() + self.Owner:GetViewModel():SequenceDuration() * 2 )
self.Iron = 0
self.Reloading = 0
self.ReloadingTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration() * 2
self.Holstering = 1
self.HolsteringTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
self.HolsteringWeapon = wep:GetClass()
self.Sprint = 0
self.BobX = 0
self.BobDirectionX = 0
self.BobY = 0
self.BobDirectionY = 0
self.Idle = 2
self.Owner:SetWalkSpeed( 200 )
self.Weapon:SetNWBool( "Crosshair", true )
self.Weapon:SetNWBool( "Holster", true )
return
end
if !IsValid( wep ) || self.Weapon:GetNWBool( "Holster" ) == true then
return true
end
end

function SWEP:HolsterEnd()
self.Holstering = 0
if SERVER then
self.Owner:SelectWeapon( self.HolsteringWeapon )
end
end

function SWEP:PrimaryAttack()
if ( self.Weapon:Clip1() <= 0 and self.Weapon:Ammo1() <= 0 ) || ( self.FiresUnderwater == false and self.Owner:WaterLevel() == 3 ) then
if SERVER then
self.Owner:EmitSound( "Weapon_CoD4.DryFirePistol" )
end
self.Weapon:SetNextPrimaryFire( CurTime() + 0.5 )
end
if self.Weapon:Clip1() <= 0 and self.Weapon:Ammo1() > 0 then
self.Weapon:Reload()
end
if self.Weapon:Clip1() <= 0 || ( self.FiresUnderwater == false and self.Owner:WaterLevel() == 3 ) then
return
end
local bullet = {}
bullet.Num = self.Primary.NumberofShots
bullet.Src = self.Owner:GetShootPos()
bullet.Dir = self.Owner:GetAimVector() - self.Owner:EyeAngles():Right() * self.Owner:GetViewPunchAngles().y * 0.015 - self.Owner:EyeAngles():Up() * self.Owner:GetViewPunchAngles().x * 0.015
bullet.Spread = Vector( self.Primary.Spread, self.Primary.Spread, 0 )
bullet.Tracer = 0
bullet.Force = self.Primary.Force
bullet.Damage = self.Primary.Damage
bullet.AmmoType = self.Primary.Ammo
bullet.Callback = function( attacker, tr, dmginfo )
if !( tr.Entity:IsNPC() || tr.Entity:IsPlayer() ) then
local tr = util.TraceLine( {
start = tr.HitPos - tr.HitNormal * self.Primary.Penetration,
endpos = tr.HitPos - tr.HitNormal * ( self.Primary.Penetration + 1 ),
filter = self.Owner
} )
if !tr.Hit then
local bullet = {}
bullet.Num = self.Primary.NumberofShots
bullet.Src = tr.HitPos - tr.HitNormal * self.Primary.Penetration
bullet.Dir = self.Owner:GetAimVector()
bullet.Spread = Vector( self.Primary.Spread, self.Primary.Spread, 0 )
bullet.Tracer = 0
bullet.Force = self.Primary.Force
bullet.Damage = self.Primary.Damage * self.Primary.PenetrationModifier
bullet.AmmoType = self.Primary.Ammo
self.Owner:FireBullets( bullet )
end
end
end
self.Owner:FireBullets( bullet )
self.Weapon:ShootEffects()
self.Weapon:TakePrimaryAmmo( self.Primary.TakeAmmo )
self.Weapon:SetNextPrimaryFire( CurTime() + self.Primary.Delay )
if self.Primary.Spread < self.Primary.SpreadMax then
if self.Iron == 0 then
self.Primary.Spread = self.Primary.Spread + self.Primary.SpreadKick
end
if self.Iron == 1 then
self.Primary.Spread = self.Primary.Spread + self.Primary.SpreadKickIron
end
end
self.Primary.SpreadTimer = CurTime() + self.Primary.SpreadTime
self.ReloadingTimer = CurTime() + self.Primary.Delay
if self.Iron == 0 then
self.Idle = 0
self.IdleTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
end
if self.Iron == 1 then
self.Idle = 2
end
end

function SWEP:ShootEffects()
self.Weapon:EmitSound( self.Primary.Sound )
if !self.Owner:KeyDown( IN_ATTACK2 ) then
self.Weapon:SendWeaponAnim( ACT_VM_PRIMARYATTACK )
self.Owner:ViewPunch( Angle( -3, 0, math.Rand( -2, 2 ) ) )
end
if self.Owner:KeyDown( IN_ATTACK2 ) then
self.Weapon:SendWeaponAnim( ACT_VM_PRIMARYATTACK_DEPLOYED )
self.Owner:ViewPunch( Angle( -1.5, 0, math.Rand( -1, 1 ) ) )
end
self.Owner:SetAnimation( PLAYER_ATTACK1 )
self.Owner:MuzzleFlash()
end

function SWEP:DynamicSpread()
if self.Owner:IsOnGround() then
if self.Owner:GetVelocity():Length() <= 125 then
if self.Primary.SpreadTimer <= CurTime() then
self.Primary.Spread = self.Primary.SpreadMin
end
if self.Primary.Spread > self.Primary.SpreadMin then
self.Primary.Spread = ( ( self.Primary.SpreadTimer - CurTime() ) / self.Primary.SpreadTime ) * self.Primary.Spread
end
end
if self.Owner:GetVelocity():Length() <= 125 and self.Primary.Spread > self.Primary.SpreadMax then
self.Primary.Spread = self.Primary.SpreadMax
end
if self.Owner:GetVelocity():Length() > 125 then
self.Primary.Spread = self.Primary.SpreadMax
self.Primary.SpreadTimer = CurTime() + self.Primary.SpreadTime
if self.Primary.Spread > self.Primary.SpreadMax then
self.Primary.Spread = ( ( self.Primary.SpreadTimer - CurTime() ) / self.Primary.SpreadTime ) * self.Primary.SpreadMax
end
end
end
if !self.Owner:IsOnGround() then
self.Primary.Spread = self.Primary.SpreadMax
self.Primary.SpreadTimer = CurTime() + self.Primary.SpreadTime
if self.Primary.Spread > self.Primary.SpreadMin then
self.Primary.Spread = ( ( self.Primary.SpreadTimer - CurTime() ) / self.Primary.SpreadTime ) * self.Primary.SpreadMax
end
end
end

function SWEP:SecondaryAttack()
if self.Iron == 0 then
self.Weapon:IronIn()
end
end

function SWEP:IronIn()
self.Weapon:SendWeaponAnim( ACT_VM_DEPLOY )
self.Iron = 1
self.Idle = 2
self.Owner:SetWalkSpeed( 175 )
self.Weapon:SetNWBool( "Crosshair", false )
end

function SWEP:IronOut()
self.Weapon:SendWeaponAnim( ACT_VM_UNDEPLOY )
self.Iron = 0
self.Idle = 0
self.IdleTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
self.Owner:SetWalkSpeed( 200 )
self.Weapon:SetNWBool( "Crosshair", true )
end

function SWEP:Reload()
if self.Reloading == 0 and self.ReloadingTimer <= CurTime() and self.Sprint == 0 and self.Weapon:Clip1() < self.Primary.ClipSize and self.Weapon:Ammo1() > 0 then
if self.Weapon:Clip1() > 0 then
self.Weapon:SendWeaponAnim( ACT_VM_RELOAD )
self.ReloadingTimer = CurTime() + self.ReloadingTime
end
if self.Weapon:Clip1() <= 0 then
self.Weapon:SendWeaponAnim( ACT_VM_RELOAD_EMPTY )
self.ReloadingTimer = CurTime() + self.ReloadingEmptyTime
end
self.Owner:SetAnimation( PLAYER_RELOAD )
self.Weapon:SetNextPrimaryFire( CurTime() + self.Owner:GetViewModel():SequenceDuration() )
self.Weapon:SetNextSecondaryFire( CurTime() + self.Owner:GetViewModel():SequenceDuration() )
self.Iron = 0
self.Reloading = 1
self.Idle = 0
self.IdleTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
self.Owner:SetWalkSpeed( 200 )
self.Weapon:SetNWBool( "Crosshair", false )
end
end

function SWEP:ReloadEnd()
if self.Weapon:Ammo1() > ( self.Primary.ClipSize - self.Weapon:Clip1() ) then
self.Owner:SetAmmo( self.Weapon:Ammo1() - self.Primary.ClipSize + self.Weapon:Clip1(), self.Primary.Ammo )
self.Weapon:SetClip1( self.Primary.ClipSize )
end
if ( self.Weapon:Ammo1() - self.Primary.ClipSize + self.Weapon:Clip1() ) + self.Weapon:Clip1() < self.Primary.ClipSize then
self.Weapon:SetClip1( self.Weapon:Clip1() + self.Weapon:Ammo1() )
self.Owner:SetAmmo( 0, self.Primary.Ammo )
end
self.Reloading = 0
self.Weapon:SetNWBool( "Crosshair", true )
end

function SWEP:SprintStart()
if SERVER then
self.Weapon:SendWeaponAnim( ACT_VM_DEPLOY_1 )
end
self.Iron = 0
if self.Reloading == 1 then
self.ReloadingTimer = CurTime()
end
self.Reloading = 0
self.Sprint = 1
self.Idle = 0
self.IdleTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
self.Owner:SetWalkSpeed( 200 )
self.Weapon:SetNWBool( "Crosshair", false )
end

function SWEP:SprintFinish()
if SERVER then
self.Weapon:SendWeaponAnim( ACT_VM_UNDEPLOY_1 )
end
self.Weapon:SetNextPrimaryFire( CurTime() + self.Owner:GetViewModel():SequenceDuration() )
self.Weapon:SetNextSecondaryFire( CurTime() + self.Owner:GetViewModel():SequenceDuration() )
self.ReloadingTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
self.Sprint = 0
self.Idle = 0
self.IdleTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
self.Weapon:SetNWBool( "Crosshair", true )
end

function SWEP:Bobbing()
if self.BobX >= -90 and self.BobDirectionX == 0 then
if game.SinglePlayer() then
if self.Sprint == 0 then
self.BobX = self.BobX - FrameTime() * ( self.Owner:GetVelocity():Length() / 200 ) * 4 * GetConVar( "cod4_viewmodel_bobbing" ):GetInt()
end
if self.Sprint == 1 then
self.BobX = self.BobX - FrameTime() * ( self.Owner:GetVelocity():Length() / 400 ) * 5 * GetConVar( "cod4_viewmodel_bobbing" ):GetInt()
end
end
if !game.SinglePlayer() then
if self.Sprint == 0 then
self.BobX = self.BobX - FrameTime() * ( self.Owner:GetVelocity():Length() / 200 ) * 8 * GetConVar( "cod4_viewmodel_bobbing" ):GetInt()
end
if self.Sprint == 1 then
self.BobX = self.BobX - FrameTime() * ( self.Owner:GetVelocity():Length() / 400 ) * 10 * GetConVar( "cod4_viewmodel_bobbing" ):GetInt()
end
end
end
if self.BobX < -90 then
self.BobDirectionX = 1
end
if self.BobX <= 90 and self.BobDirectionX == 1 then
if game.SinglePlayer() then
if self.Sprint == 0 then
self.BobX = self.BobX + FrameTime() * ( self.Owner:GetVelocity():Length() / 200 ) * 4 * GetConVar( "cod4_viewmodel_bobbing" ):GetInt()
end
if self.Sprint == 1 then
self.BobX = self.BobX + FrameTime() * ( self.Owner:GetVelocity():Length() / 400 ) * 5 * GetConVar( "cod4_viewmodel_bobbing" ):GetInt()
end
end
if !game.SinglePlayer() then
if self.Sprint == 0 then
self.BobX = self.BobX + FrameTime() * ( self.Owner:GetVelocity():Length() / 200 ) * 8 * GetConVar( "cod4_viewmodel_bobbing" ):GetInt()
end
if self.Sprint == 1 then
self.BobX = self.BobX + FrameTime() * ( self.Owner:GetVelocity():Length() / 400 ) * 10 * GetConVar( "cod4_viewmodel_bobbing" ):GetInt()
end
end
end
if self.BobX > 90 then
self.BobDirectionX = 0
end
if self.BobY >= -45 and self.BobDirectionY == 0 then
if game.SinglePlayer() then
if self.Sprint == 0 then
self.BobY = self.BobY - FrameTime() * ( self.Owner:GetVelocity():Length() / 200 ) * 8 * GetConVar( "cod4_viewmodel_bobbing" ):GetInt()
end
if self.Sprint == 1 then
self.BobY = self.BobY - FrameTime() * ( self.Owner:GetVelocity():Length() / 400 ) * 10 * GetConVar( "cod4_viewmodel_bobbing" ):GetInt()
end
end
if !game.SinglePlayer() then
if self.Sprint == 0 then
self.BobY = self.BobY - FrameTime() * ( self.Owner:GetVelocity():Length() / 200 ) * 16 * GetConVar( "cod4_viewmodel_bobbing" ):GetInt()
end
if self.Sprint == 1 then
self.BobY = self.BobY - FrameTime() * ( self.Owner:GetVelocity():Length() / 400 ) * 20 * GetConVar( "cod4_viewmodel_bobbing" ):GetInt()
end
end
end
if self.BobY < -45 then
self.BobDirectionY = 1
end
if self.BobY <= 45 and self.BobDirectionY == 1 then
if game.SinglePlayer() then
if self.Sprint == 0 then
self.BobY = self.BobY + FrameTime() * ( self.Owner:GetVelocity():Length() / 200 ) * 8 * GetConVar( "cod4_viewmodel_bobbing" ):GetInt()
end
if self.Sprint == 1 then
self.BobY = self.BobY + FrameTime() * ( self.Owner:GetVelocity():Length() / 400 ) * 10 * GetConVar( "cod4_viewmodel_bobbing" ):GetInt()
end
end
if !game.SinglePlayer() then
if self.Sprint == 0 then
self.BobY = self.BobY + FrameTime() * ( self.Owner:GetVelocity():Length() / 200 ) * 16 * GetConVar( "cod4_viewmodel_bobbing" ):GetInt()
end
if self.Sprint == 1 then
self.BobY = self.BobY + FrameTime() * ( self.Owner:GetVelocity():Length() / 400 ) * 20 * GetConVar( "cod4_viewmodel_bobbing" ):GetInt()
end
end
end
if self.BobY > 45 then
self.BobDirectionY = 0
end
end

function SWEP:IdleAnimation()
if self.Idle == 0 then
self.Idle = 1
end
if SERVER and self.Idle == 1 then
if self.Sprint == 0 then
self.Weapon:SendWeaponAnim( ACT_VM_IDLE )
end
if self.Sprint == 1 then
self.Weapon:SendWeaponAnim( ACT_VM_IDLE_DEPLOYED_1 )
end
end
self.IdleTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
end

function SWEP:Think()
self.ViewModelFOV = GetConVar( "cod4_viewmodel_fov" ):GetInt()
self.Weapon:DynamicSpread()
if self.Weapon:Clip1() > 0 then
self.Primary.Automatic = false
end
if self.Weapon:Clip1() <= 0 and self.Weapon:Ammo1() <= 0 then
self.Primary.Automatic = true
end
if self.Iron == 1 and !self.Owner:KeyDown( IN_ATTACK2 ) then
self.Weapon:IronOut()
end
if self.Reloading == 1 and self.ReloadingTimer <= CurTime() then
self.Weapon:ReloadEnd()
end
if self.Holstering == 1 and self.HolsteringTimer <= CurTime() then
self.Weapon:HolsterEnd()
end
if self.Reloading == 1 || self.ReloadingTimer <= CurTime() then
if self.Sprint == 0 and self.Owner:IsOnGround() and self.Owner:GetVelocity():Length() >= 100 and self.Owner:KeyDown( IN_SPEED ) and ( self.Owner:KeyDown( IN_FORWARD ) || self.Owner:KeyDown( IN_BACK ) || self.Owner:KeyDown( IN_MOVELEFT ) || self.Owner:KeyDown( IN_MOVERIGHT ) ) then
self.Weapon:SprintStart()
end
if self.Sprint == 1 and ( !self.Owner:IsOnGround() || self.Owner:GetVelocity():Length() < 100 || !self.Owner:KeyDown( IN_SPEED ) || !( self.Owner:KeyDown( IN_FORWARD ) || self.Owner:KeyDown( IN_BACK ) || self.Owner:KeyDown( IN_MOVELEFT ) || self.Owner:KeyDown( IN_MOVERIGHT ) ) ) then
self.Weapon:SprintFinish()
end
end
if self.Sprint == 0 then
self.Weapon:SetHoldType( self.HoldType )
end
if self.Sprint == 1 then
self.Weapon:SetHoldType( self.HoldTypeSprint )
self.Weapon:SetNextPrimaryFire( CurTime() + 0.2 )
self.Weapon:SetNextSecondaryFire( CurTime() + 0.2 )
end
if self.Owner:IsOnGround() then
self.Weapon:Bobbing()
end
if self.IdleTimer <= CurTime() then
self.Weapon:IdleAnimation()
end
end