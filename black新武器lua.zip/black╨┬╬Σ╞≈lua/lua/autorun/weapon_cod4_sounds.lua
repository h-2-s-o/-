sound.Add(
{
name = "Weapon_CoD4.DryFirePistol",
channel = CHAN_ITEM,
volume = 0.5,
sound = "cod4/weapons/weap_dryfire_pistol.wav"
} )
sound.Add(
{
name = "Weapon_CoD4.DryFireRifle",
channel = CHAN_ITEM,
volume = 0.5,
sound = "cod4/weapons/weap_dryfire_rifle.wav"
} )
sound.Add(
{
name = "Weapon_CoD4.DryFireSMG",
channel = CHAN_ITEM,
volume = 0.5,
sound = "cod4/weapons/weap_dryfire_smg.wav"
} )
sound.Add(
{
name = "Weapon_CoD4.Weapon",
channel = CHAN_AUTO,
volume = 0.25,
sound = { "cod4/weapons/pu_weapon01.wav",
"cod4/weapons/pu_weapon02.wav",
"cod4/weapons/pu_weapon04.wav" }
} )
sound.Add(
{
name = "Weapon_CoD4.WeaponArm",
channel = CHAN_ITEM,
volume = 0.25,
sound = "cod4/weapons/wpnarm_2.wav"
} )