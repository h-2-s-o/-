sound.Add(
{
name = "Weapon_CoD4_Colt45.Single",
channel = CHAN_WEAPON,
level = 140,
sound = "cod4/weapons/colt45/weap_usp45_slst_y1b.wav"
} )
sound.Add(
{
name = "Weapon_CoD4_Colt45.Silenced",
channel = CHAN_WEAPON,
volume = 0.5,
sound = "cod4/weapons/colt45/weap_usp45sd_slst_y1.wav"
} )
sound.Add(
{
name = "Weapon_CoD4_Colt45.Chamber",
channel = CHAN_ITEM,
volume = 0.5,
sound = "cod4/weapons/colt45/wpfoly_colt1911_reload_chamber_v1.wav"
} )
sound.Add(
{
name = "Weapon_CoD4_Colt45.ClipIn",
channel = CHAN_ITEM,
volume = 0.5,
sound = "cod4/weapons/colt45/wpfoly_colt1911_reload_clipin_v1.wav"
} )
sound.Add(
{
name = "Weapon_CoD4_Colt45.ClipOut",
channel = CHAN_ITEM,
volume = 0.5,
sound = "cod4/weapons/colt45/wpfoly_colt1911_reload_clipout_v1.wav"
} )
sound.Add(
{
name = "Weapon_CoD4_Colt45.Lift",
channel = CHAN_ITEM,
volume = 0.5,
sound = "cod4/weapons/colt45/wpfoly_colt1911_reload_lift_v1.wav"
} )