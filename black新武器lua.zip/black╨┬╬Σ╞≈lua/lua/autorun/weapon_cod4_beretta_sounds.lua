sound.Add(
{
name = "Weapon_CoD4_Beretta.Single",
channel = CHAN_WEAPON,
level = 140,
sound = "cod4/weapons/beretta/weap_beretta_slst_3c.wav"
} )
sound.Add(
{
name = "Weapon_CoD4_Beretta.Silenced",
channel = CHAN_WEAPON,
volume = 0.5,
sound = "cod4/weapons/beretta/weap_usp45sd_slst_y1.wav"
} )
sound.Add(
{
name = "Weapon_CoD4_Beretta.Chamber",
channel = CHAN_ITEM,
volume = 0.5,
sound = "cod4/weapons/beretta/wpfoly_beretta9mm_reload_chamber_v2.wav"
} )
sound.Add(
{
name = "Weapon_CoD4_Beretta.ClipIn",
channel = CHAN_ITEM,
volume = 0.5,
sound = "cod4/weapons/beretta/wpfoly_beretta9mm_reload_clipin_v2.wav"
} )
sound.Add(
{
name = "Weapon_CoD4_Beretta.ClipOut",
channel = CHAN_ITEM,
volume = 0.5,
sound = "cod4/weapons/beretta/wpfoly_beretta9mm_reload_clipout_v2.wav"
} )