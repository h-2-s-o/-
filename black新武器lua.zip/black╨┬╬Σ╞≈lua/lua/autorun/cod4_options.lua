CreateClientConVar( "cod4_crosshair_red", 255, true, true )
CreateClientConVar( "cod4_crosshair_green", 255, true, true )
CreateClientConVar( "cod4_crosshair_blue", 255, true, true )
CreateClientConVar( "cod4_crosshair_alpha", 255, true, true )
CreateClientConVar( "cod4_viewmodel_fov", 70, true, true )
CreateClientConVar( "cod4_viewmodel_bobbing", 1, true, true )
hook.Add( "PopulateToolMenu", "CoD4Options", function()
spawnmenu.AddToolMenuOption( "Options", "Call of Duty 4: Modern Warfare", "cod4_crosshair", "Crosshair", "", "", function( panel )
panel:AddControl( "Color", {
Label = "Color",
Red = "cod4_crosshair_red",
Green = "cod4_crosshair_green",
Blue = "cod4_crosshair_blue",
Alpha = "cod4_crosshair_alpha"
} )
end )
spawnmenu.AddToolMenuOption( "Options", "Call of Duty 4: Modern Warfare", "cod4_viewmodel", "View Model", "", "", function( panel )
panel:AddControl( "Slider", {
Label = "FOV",
Command = "cod4_viewmodel_fov",
Type = "Float",
Min = "60",
Max = "80"
} )
panel:AddControl( "Slider", {
Label = "Bobbing speed",
Command = "cod4_viewmodel_bobbing",
Type = "Float",
Min = "0.0",
Max = "4.0"
} )
end )
end )