sound.Add(
{
name = "Weapon_CoD4_DesertEagle.Single",
channel = CHAN_WEAPON,
level = 140,
sound = "cod4/weapons/deserteagle/weap_deserteagle_slst_2.wav"
} )
sound.Add(
{
name = "Weapon_CoD4_DesertEagle.Chamber",
channel = CHAN_ITEM,
volume = 0.5,
sound = "cod4/weapons/deserteagle/wpfoly_de50_reload_chamber_v1.wav"
} )
sound.Add(
{
name = "Weapon_CoD4_DesertEagle.ClipIn",
channel = CHAN_ITEM,
volume = 0.5,
sound = "cod4/weapons/deserteagle/wpfoly_de50_reload_clipin_v1.wav"
} )
sound.Add(
{
name = "Weapon_CoD4_DesertEagle.ClipOut",
channel = CHAN_ITEM,
volume = 0.5,
sound = "cod4/weapons/deserteagle/wpfoly_de50_reload_clipout_v1.wav"
} )