sound.Add(
{
name = "Weapon_LMG_FirstShot",
channel = CHAN_STATIC,
volume = 1,
pitch = { 100, 120 },
soundlevel = SNDLVL_GUNFIRE,
sound = "weapons/LMG/Wpn_LMG_1p_WpnFire_FirstShot_Core_6ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_LMG_Loop",
channel = CHAN_WEAPON,
volume = 1,
pitch = { 99, 101 },
soundlevel = SNDLVL_GUNFIRE,
sound = "weapons/LMG/Wpn_LMG_1p_WpnFire_Loop_Core_6ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_LMG_LoopEnd",
channel = CHAN_WEAPON,
volume = 1,
pitch = { 140, 180 },
soundlevel = SNDLVL_GUNFIRE,
sound = "weapons/LMG/Wpn_LMG_1p_WpnFire_Tail_Core_6ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_LMG_FirstDraw",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/LMG/Wpn_LMG_FirstDraw_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_LMG_Reload_DrumRemove",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/LMG/Wpn_LMG_Reload_DrumRemove_fr5_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_LMG_Reload_DrumGrab",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/LMG/Wpn_LMG_Reload_DrumGrab_fr30_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_LMG_Reload_DrumInsert",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/LMG/Wpn_LMG_Reload_DrumInsert_fr43_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_LMG_Reload_DrumPat",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/LMG/Wpn_LMG_Reload_DrumPat_fr60_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_LMG_Reload_HandRest",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/LMG/Wpn_LMG_Reload_HandRest_fr76_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_LMG_EmptyReload_DrumRemove",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/LMG/Wpn_LMG_EmptyReload_DrumRemove_fr0_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_LMG_EmptyReload_DrumGrab",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/LMG/Wpn_LMG_EmptyReload_DrumGrab_fr22_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_LMG_EmptyReload_DrumInsert",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/LMG/Wpn_LMG_EmptyReload_DrumInsert_fr55_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_LMG_EmptyReload_DrumPat",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/LMG/Wpn_LMG_EmptyReload_DrumPat_fr69_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_LMG_EmptyReload_BoltBack",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/LMG/Wpn_LMG_EmptyReload_BoltBack_fr85_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_LMG_EmptyReload_BoltFront",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/LMG/Wpn_LMG_EmptyReload_BoltFront_fr94_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_LMG_EmptyReload_HandRest",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/LMG/Wpn_LMG_EmptyReload_HandRest_fr102_2ch_v1_01.wav"
} )