sound.Add(
{
name = "DMR_Rifle.Single",
channel = CHAN_WEAPON,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_GUNFIRE,
sound = "weapons/DMR/Wpn_DMR_1p_WpnFire_Reduced_6ch_01.wav"
} )
sound.Add(
{
name = "Weapon_R101_DMR.ADS_In",
channel = CHAN_ITEM,
volume = 0.95,
pitch = { 110, 120 },
soundlevel = SNDLVL_NORM,
sound = "weapons/Foley/Wpn_Sniper_ADS_In_LR_v2_1.wav"
} )
sound.Add(
{
name = "Weapon_R101_DMR.ADS_Out",
channel = CHAN_ITEM,
volume = 0.95,
pitch = { 110, 120 },
soundlevel = SNDLVL_NORM,
sound = "weapons/Foley/Wpn_Sniper_ADS_Out_LR_v2_1.wav"
} )
sound.Add(
{
name = "Weapon_R101_DMR.Draw",
channel = CHAN_ITEM,
volume = { 0.95, 1 },
pitch = { 98, 104 },
soundlevel = SNDLVL_NORM,
sound = "weapons/Foley/Wpn_Sniper_Draw_LR_v1_1.wav"
} )
sound.Add(
{
name = "Weapon_DMR_Reload_MagPull",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/DMR/Wpn_DMR_Reload_MagPull_fr14_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_DMR_Reload_MagGrab",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/DMR/Wpn_DMR_Reload_MagGrab_fr26_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_DMR_Reload_MagInsert",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/DMR/Wpn_DMR_Reload_MagInsert_fr40_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_DMR_Reload_HandRest",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/DMR/Wpn_DMR_Reload_HandRest_fr53_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_DMR_EmptyReload_MagPull",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/DMR/Wpn_DMR_EmptyReload_MagPull_fr8_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_DMR_EmptyReload_MagGrab",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/DMR/Wpn_DMR_EmptyReload_MagGrab_fr14_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_DMR_EmptyReload_MagInsert",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/DMR/Wpn_DMR_EmptyReload_MagInsert_fr39_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_DMR_EmptyReload_BoltBack",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/DMR/Wpn_DMR_EmptyReload_BoltBack_fr73_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_DMR_EmptyReload_BoltForward",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/DMR/Wpn_DMR_EmptyReload_BoltForward_fr80_2ch_v1_01.wav"
} )