sound.Add(
{
name = "Anti_Titan_Rifle.Single",
channel = CHAN_WEAPON,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_GUNFIRE,
sound = "weapons/Sniper_Kraber/Wpn_Sniper_1p_WpnFire_Reduced_6ch_01.wav"
} )
sound.Add(
{
name = "Weapon_Rangemaster.magout",
channel = CHAN_ITEM,
volume = 1,
pitch = { 100, 108 },
soundlevel = SNDLVL_NORM,
sound = "weapons/Sniper_Kraber/Wpn_KraberSniper_1P_Reload_MagOut_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_Rangemaster.magin",
channel = CHAN_ITEM,
volume = 1,
pitch = { 100, 108 },
soundlevel = SNDLVL_NORM,
sound = "weapons/Sniper_Kraber/Wpn_KraberSniper_1P_Reload_MagIn_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_Rangemaster.slideback",
channel = CHAN_ITEM,
volume = 1,
pitch = { 93, 106 },
soundlevel = SNDLVL_NORM,
sound = "weapons/Sniper_Kraber/Wpn_KraberSniper_1P_Reload_BoltBack_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_Rangemaster.slidefront",
channel = CHAN_ITEM,
volume = 1,
pitch = { 93, 106 },
soundlevel = SNDLVL_NORM,
sound = "weapons/Sniper_Kraber/Wpn_KraberSniper_1P_Reload_BoltForward_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_Rangemaster_Kraber.ADS_In",
channel = CHAN_ITEM,
volume = 0.95,
pitch = { 110, 120 },
soundlevel = SNDLVL_NORM,
sound = "weapons/Foley/Wpn_Sniper_ADS_In_LR_v2_1.wav"
} )
sound.Add(
{
name = "Weapon_Rangemaster_Kraber.ADS_Out",
channel = CHAN_ITEM,
volume = 0.95,
pitch = { 110, 120 },
soundlevel = SNDLVL_NORM,
sound = "weapons/Foley/Wpn_Sniper_ADS_Out_LR_v2_1.wav"
} )
sound.Add(
{
name = "Weapon_Rangemaster_Kraber.Draw",
channel = CHAN_ITEM,
volume = { 0.95, 1 },
pitch = { 98, 104 },
soundlevel = SNDLVL_NORM,
sound = "weapons/Foley/Wpn_Sniper_Draw_LR_v1_1.wav"
} )