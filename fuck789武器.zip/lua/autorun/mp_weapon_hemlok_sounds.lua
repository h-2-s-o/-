sound.Add(
{
name = "Weapon_hemlok.FirstShot",
channel = CHAN_WEAPON,
volume = 1,
pitch = 92,
soundlevel = SNDLVL_GUNFIRE,
sound = "weapons/Hemlok/Wpn_Hemlok_1p_WpnFire_Core_3ShotBurst_6ch_v1_01.wav"
} )
sound.Add(
{
name = "Wpn_Hemlok_Reload_MoveArm",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/Hemlok/Wpn_Hemlok_Reload_MoveArm_fr0_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Wpn_Hemlok_Reload_RemoveMag",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/Hemlok/Wpn_Hemlok_Reload_RemoveMag_fr15_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Wpn_Hemlok_Reload_InsertMag",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/Hemlok/Wpn_Hemlok_Reload_InsertMag_fr36_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Wpn_Hemlok_Reload_PopMag",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/Hemlok/Wpn_Hemlok_Reload_PopMag_fr50_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Wpn_Hemlok_Reload_HandGrab",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/Hemlok/Wpn_Hemlok_Reload_HandGrab_fr57_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Wpn_Hemlok_Reload_Empty_ChargeBack",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 120 },
soundlevel = SNDLVL_NORM,
sound = "weapons/Hemlok/Wpn_Hemlok_Reload_Empty_ChargeBack_fr68_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Wpn_Hemlok_Reload_Empty_ChargeForward",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 120 },
soundlevel = SNDLVL_NORM,
sound = "weapons/Hemlok/Wpn_Hemlok_Reload_Empty_ChargeForward_fr76_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Wpn_Hemlok_Reload_Empty_HandGrab",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/Hemlok/Wpn_Hemlok_Reload_Empty_HandGrab_fr85_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Wpn_Hemlok_Reload_Empty_InsertMag",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/Hemlok/Wpn_Hemlok_Reload_Empty_InsertMag_fr39_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Wpn_Hemlok_Reload_Empty_PopMag",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/Hemlok/Wpn_Hemlok_Reload_Empty_PopMag_fr54_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Wpn_Hemlok_Reload_Empty_RemoveMag",
channel = CHAN_ITEM,
volume = 1,
pitch = { 90, 110 },
soundlevel = SNDLVL_NORM,
sound = "weapons/Hemlok/Wpn_Hemlok_Reload_Empty_RemoveMag_fr10_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_hemlok.weaponup",
channel = CHAN_ITEM,
volume = 0.85,
pitch = { 98, 104 },
soundlevel = SNDLVL_NORM,
sound = "weapons/Foley/Wpn_Rifle_Draw_LR_v1_1.wav"
} )
sound.Add(
{
name = "Weapon_hemlok.ADS_In",
channel = CHAN_ITEM,
volume = 0.95,
pitch = { 110, 120 },
soundlevel = SNDLVL_NORM,
sound = "weapons/Foley/Wpn_Rifle_ADS_In_LR_v1_1.wav"
} )
sound.Add(
{
name = "Weapon_hemlok.ADS_Out",
channel = CHAN_ITEM,
volume = 0.95,
pitch = { 110, 120 },
soundlevel = SNDLVL_NORM,
sound = "weapons/Foley/Wpn_Rifle_ADS_Out_LR_v1_1.wav"
} )