sound.Add(
{
name = "Dragons_Breath.Single",
channel = CHAN_WEAPON,
volume = 1,
pitch = { 95, 105 },
soundlevel = SNDLVL_GUNFIRE,
sound = "weapons/shotgun/Wpn_Shotgun_1p_WpnFire_Reduced_6ch_01.wav"
} )
sound.Add(
{
name = "Player_R1Shotgun_Reload_Pull_Clip",
channel = CHAN_ITEM,
volume = 0.87,
pitch = { 90, 105 },
soundlevel = SNDLVL_NORM,
sound = "weapons/shotgun/Wpn_Shotgun_Reload_PullDrum_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Player_R1Shotgun_Reload_New_Clip",
channel = CHAN_ITEM,
volume = 0.87,
pitch = { 95, 105 },
soundlevel = SNDLVL_NORM,
sound = "weapons/shotgun/Wpn_Shotgun_Reload_InsertDrum_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Player_R1Shotgun_Reload_HandGrab",
channel = CHAN_ITEM,
volume = 0.87,
pitch = { 95, 105 },
soundlevel = SNDLVL_NORM,
sound = "weapons/shotgun/Wpn_Shotgun_Reload_HandGrab_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Player_R1Shotgun_Reload_Pump_In",
channel = CHAN_ITEM,
volume = 1,
pitch = { 95, 105 },
soundlevel = SNDLVL_NORM,
sound = "weapons/shotgun/Wpn_Shotgun_Reload_PumpIn_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Player_R1Shotgun_Reload_Pump_Out",
channel = CHAN_ITEM,
volume = 1,
pitch = { 95, 105 },
soundlevel = SNDLVL_NORM,
sound = "weapons/shotgun/Wpn_Shotgun_Reload_PumpOut_2ch_v1_01.wav"
} )
sound.Add(
{
name = "Weapon_EVA8.ADS_In",
channel = CHAN_ITEM,
volume = 0.95,
pitch = { 110, 120 },
soundlevel = SNDLVL_NORM,
sound = "weapons/R101/R101_1P_ADSIn_v2_1.wav"
} )
sound.Add(
{
name = "Weapon_EVA8.ADS_Out",
channel = CHAN_ITEM,
volume = 0.95,
pitch = { 110, 120 },
soundlevel = SNDLVL_NORM,
sound = "weapons/R101/R101_1P_ADSIn_v2_1.wav"
} )
sound.Add(
{
name = "Weapon_EVA8.Draw",
channel = CHAN_ITEM,
volume = { 0.95, 1 },
pitch = { 98, 104 },
soundlevel = SNDLVL_NORM,
sound = "weapons/Foley/Wpn_Rifle_Draw_LR_v1_1.wav"
} )