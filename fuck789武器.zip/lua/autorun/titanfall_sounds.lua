sound.Add(
{
name = "assault_rifle_dryfire",
channel = CHAN_ITEM,
volume = 1,
pitch = 100,
soundlevel = SNDLVL_NORM,
sound = "weapons/dryfires/assault_rifle_dryfire_01.wav"
} )
sound.Add(
{
name = "rifle_dryfire",
channel = CHAN_ITEM,
volume = 1,
pitch = 100,
soundlevel = SNDLVL_NORM,
sound = "weapons/dryfires/rifle_dryfire_01.wav"
} )
sound.Add(
{
name = "hemlok_dryfire",
channel = CHAN_ITEM,
volume = 1,
pitch = 100,
soundlevel = SNDLVL_NORM,
sound = "weapons/dryfires/hemlok_dryfire_01.wav"
} )
sound.Add(
{
name = "pistol_dryfire",
channel = CHAN_ITEM,
volume = 1,
pitch = 100,
soundlevel = SNDLVL_NORM,
sound = "weapons/dryfires/pistol_dryfire_01.wav"
} )
sound.Add(
{
name = "shotgun_dryfire",
channel = CHAN_ITEM,
volume = 1,
pitch = 100,
soundlevel = SNDLVL_NORM,
sound = "weapons/dryfires/shotgun_dryfire_01.wav"
} )
sound.Add(
{
name = "player_melee_kick_1P",
channel = CHAN_ITEM,
volume = 1,
pitch = 100,
soundlevel = SNDLVL_NORM,
sound = "player/melee/Mvmt_Human_1p_MeleeKick_2ch_v6_01.wav"
} )