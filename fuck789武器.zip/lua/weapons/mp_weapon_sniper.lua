if CLIENT then
SWEP.WepSelectIcon = surface.GetTextureID( "ui/menu/items/weapon_sniper" )
SWEP.DrawWeaponInfoBox	= false
SWEP.BounceWeaponIcon = false
killicon.Add( "mp_weapon_sniper", "ui/menu/items/weapon_sniper", Color( 0, 0, 0, 255 ) )
end

SWEP.PrintName = "Kraber-AP Sniper"
SWEP.Category = "Titanfall"
SWEP.Spawnable= true
SWEP.AdminSpawnable= true
SWEP.AdminOnly = false

SWEP.ViewModelFOV = 60
SWEP.ViewModel = "models/weapons/at_rifle/ptpov_at_rifle.mdl"
SWEP.WorldModel = "models/weapons/at_rifle/w_at_rifle.mdl"
SWEP.ViewModelFlip = false
SWEP.SwayScale = 0.5
SWEP.BobScale = 0.5

SWEP.AutoSwitchTo = false
SWEP.AutoSwitchFrom = false
SWEP.Weight = 15
SWEP.Slot = 3
SWEP.SlotPos = 0

SWEP.UseHands = false
SWEP.HoldType = "ar2"
SWEP.FiresUnderwater = true
SWEP.DrawCrosshair = false
SWEP.DrawAmmo = true
SWEP.CSMuzzleFlashes = 1
SWEP.Base = "weapon_base"

SWEP.Iron = 0
SWEP.IronInTime = 0.45
SWEP.IronOutTime = 0.2
SWEP.DeployTime = 0.8
SWEP.Reload = 0
SWEP.ReloadingTimer = CurTime()
SWEP.ReloadTime = 1.5
SWEP.ReloadEmptyTime = 2.61
SWEP.Sprint = 0
SWEP.Bob = 0
SWEP.BobTimer = CurTime()
SWEP.Attack = 0
SWEP.Idle = 0
SWEP.IdleTimer = CurTime()
SWEP.Active = 0
SWEP.Chamber = 0

SWEP.Primary.Sound = Sound( "Anti_Titan_Rifle.Single" )
SWEP.Primary.ClipSize = 5
SWEP.Primary.DefaultClip = 60
SWEP.Primary.MaxAmmo = 55
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "SniperRound"
SWEP.Primary.Damage = 500
SWEP.Primary.TakeAmmo = 1
SWEP.Primary.SpreadOriginal = 10
SWEP.Primary.SpreadIron = 0.1
SWEP.Primary.NumberofShots = 1
SWEP.Primary.Delay = 0.54
SWEP.Primary.DelayChamber = 1.3
SWEP.Primary.Force = 1

SWEP.Secondary.Sound = Sound( "player_melee_kick_1P" )
SWEP.Secondary.ClipSize = 0
SWEP.Secondary.DefaultClip = 0
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

function SWEP:Initialize()
self:SetWeaponHoldType( self.HoldType )
self.Idle = 0
self.IdleTimer = CurTime() + 0.5
self.Chamber = 0
end

function SWEP:Deploy()
self:SetWeaponHoldType( self.HoldType )
self.Weapon:SendWeaponAnim( ACT_VM_DRAW )
self:SetNextPrimaryFire( CurTime() + self.DeployTime )
self:SetNextSecondaryFire( CurTime() + self.DeployTime )
self.Iron = 0
self.Reloading = 0
self.ReloadingTimer = CurTime()
self.Sprint = 0
self.Bob = 0
self.BobTimer = CurTime()
self.Attack = 0
self.Idle = 0
self.IdleTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
self.Active = 1
self.Owner:SetWalkSpeed( 200 )
self.Weapon:SetNWString( "BobSway", 0.5 )
end

function SWEP:Holster()
if self.Attack == 1 then return end
self.Iron = 0
self.Reloading = 0
self.ReloadingTimer = CurTime()
self.Sprint = 0
self.Bob = 0
self.BobTimer = CurTime()
self.Idle = 0
self.IdleTimer = CurTime()
self.Active = 0
self.Owner:SetWalkSpeed( 200 )
self.Weapon:SetNWString( "BobSway", 0.5 )
return true
end

function SWEP:PrimaryAttack()
if self.Reloading == 1 then return end
if self.Sprint == 1 then return end
if self.Weapon:Clip1() <= 0 and self.Weapon:Ammo1() <= 0 and !( self.Owner:WaterLevel() == 3 ) then
self.Weapon:EmitSound( "rifle_dryfire" )
self:SetNextPrimaryFire( CurTime() + 0.2 )
end
if self.FiresUnderwater == false and self.Owner:WaterLevel() == 3 then
self.Weapon:EmitSound( "rifle_dryfire" )
self:SetNextPrimaryFire( CurTime() + 0.2 )
end
if self.Weapon:Clip1() <= 0 then
self:Reload()
end
if self.Weapon:Clip1() > 0 and !self.Owner:KeyDown( IN_USE ) then
if self.FiresUnderwater == false and self.Owner:WaterLevel() == 3 then return end
local bullet = {}
bullet.Num = self.Primary.NumberofShots
bullet.Src = self.Owner:GetShootPos()
bullet.Dir = self.Owner:GetAimVector()
if self.Iron == 0 then
bullet.Spread = Vector( self.Primary.SpreadOriginal * 0.01, self.Primary.SpreadOriginal * 0.01, 0 )
end
if self.Iron == 1 then
bullet.Spread = Vector( self.Primary.SpreadIron * 0.01, self.Primary.SpreadIron * 0.01, 0 )
end
bullet.Tracer = 1
bullet.Force = self.Primary.Force
bullet.Damage = self.Primary.Damage
bullet.AmmoType = self.Primary.Ammo
self.Owner:FireBullets( bullet )
self:EmitSound( self.Primary.Sound )
self.Owner:SetAnimation( PLAYER_ATTACK1 )
self.Owner:MuzzleFlash()
self.Owner:SetEyeAngles( self.Owner:EyeAngles() + Angle( -0.325, math.Rand( -0.12, 0.12 ), 0 ) )
self.Owner:ViewPunchReset()
self.Owner:ViewPunch( Angle( -0.5625, math.Rand( -0.135, 0.135 ), 0 ) )
self:TakePrimaryAmmo( self.Primary.TakeAmmo )
self:SetNextPrimaryFire( CurTime() + self.Primary.Delay )
self:SetNextSecondaryFire( CurTime() + self.Primary.Delay )
if self.Iron == 0 then
self.Weapon:SendWeaponAnim( ACT_VM_PRIMARYATTACK )
end
if self.Iron == 1 then
self.Weapon:SendWeaponAnim( ACT_VM_PRIMARYATTACK_DEPLOYED )
end
if self.Weapon:Clip1() > 0 then
self.Chamber = 1
end
if !self.Owner:KeyDown( IN_USE ) then
self.Idle = 0
self.IdleTimer = CurTime() + self.Primary.Delay
end
end
if self.Owner:KeyDown( IN_USE ) and self.Iron == 0 and self.Reloading == 0 then
self:EmitSound( self.Secondary.Sound )
self.Weapon:SendWeaponAnim( ACT_VM_SECONDARYATTACK )
self.Owner:DoAnimationEvent( ACT_GMOD_GESTURE_MELEE_SHOVE_1HAND )
self.Owner:ViewPunchReset()
self.Owner:ViewPunch( Angle( 2, -0.4, -0.8 ) )
self:SetNextPrimaryFire( CurTime() + 1.2 )
self:SetNextSecondaryFire( CurTime() + 1.2 )
self.Idle = 0
self.IdleTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
self.Attack = 1
timer.Simple( 0.4, function()
if self.Attack == 1 then
self.Owner:LagCompensation( true )
local tr = util.TraceLine( {
start = self.Owner:GetShootPos(),
endpos = self.Owner:GetShootPos() + self.Owner:GetAimVector() * 75,
filter = self.Owner,
mask = MASK_SHOT_HULL,
} )
if !IsValid( tr.Entity ) then
tr = util.TraceHull( {
start = self.Owner:GetShootPos(),
endpos = self.Owner:GetShootPos() + self.Owner:GetAimVector() * 75,
filter = self.Owner,
mins = Vector( -16, -16, 0 ),
maxs = Vector( 16, 16, 0 ),
mask = MASK_SHOT_HULL,
} )
end
if SERVER and IsValid( tr.Entity ) then
local dmginfo = DamageInfo()
local attacker = self.Owner
if !IsValid( attacker ) then
attacker = self
end
dmginfo:SetAttacker( attacker )
dmginfo:SetInflictor( self )
dmginfo:SetDamage( 100 )
dmginfo:SetDamageForce( self.Owner:GetForward() * 5000 )
tr.Entity:TakeDamageInfo( dmginfo )
end
self.Owner:LagCompensation( false )
self.Owner:ViewPunch( Angle( -2, 0.8, 0.4 ) )
self.Attack = 0
end
end )
end
end

function SWEP:SecondaryAttack()
if self.Reloading == 1 then return end
if self.Attack == 1 then return end
if self.Sprint == 1 then return end
if self.Iron == 0 then
self.Weapon:SendWeaponAnim( ACT_VM_DEPLOY )
self:SetNextPrimaryFire( CurTime() + self.IronInTime )
self:SetNextSecondaryFire( CurTime() + self.IronInTime )
self.Iron = 1
self.Idle = 0
self.IdleTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
timer.Simple( 0.2, function()
if self.Active == 1 and self.Iron == 1 then
self.Owner:SetFOV( 40, 0 )
end
end )
self.Owner:SetWalkSpeed( 100 )
if SERVER then
self.Owner:EmitSound( "Weapon_Rangemaster_Kraber.ADS_In" )
end
self.Weapon:SetNWString( "BobSway", 0 )
else
if self.Iron == 1 then
self.Weapon:SendWeaponAnim( ACT_VM_UNDEPLOY )
self:SetNextPrimaryFire( CurTime() + self.IronOutTime )
self:SetNextSecondaryFire( CurTime() + self.IronOutTime )
self.Iron = 0
self.Idle = 0
self.IdleTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
self.Owner:SetFOV( 0, self.IronOutTime )
self.Owner:SetWalkSpeed( 200 )
if SERVER then
self.Owner:EmitSound( "Weapon_Rangemaster_Kraber.ADS_Out" )
end
self.Weapon:SetNWString( "BobSway", 0.5 )
end
end
end

function SWEP:Reload()
if self.Reloading == 0 and self.Weapon:Clip1() < self.Primary.ClipSize and self.Weapon:Ammo1() > 0 and self.Chamber == 0 then
if self.Weapon:Clip1() > 0 then
self.Weapon:SendWeaponAnim( ACT_VM_RELOAD )
self.ReloadingTimer = CurTime() + self.ReloadTime
end
if self.Weapon:Clip1() <= 0 then
self.Weapon:SendWeaponAnim( ACT_VM_RELOAD_EMPTY )
self.ReloadingTimer = CurTime() + self.ReloadEmptyTime
end
self.Owner:SetAnimation( PLAYER_RELOAD )
self:SetNextPrimaryFire( CurTime() + self.Owner:GetViewModel():SequenceDuration() )
self:SetNextSecondaryFire( CurTime() + self.Owner:GetViewModel():SequenceDuration() )
self.Iron = 0
self.Sprint = 0
self.Bob = 0
self.BobTimer = CurTime()
self.Attack = 0
self.Reloading = 1
self.Idle = 0
self.IdleTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
self.Owner:SetFOV( 0, self.IronOutTime )
self.Owner:SetWalkSpeed( 200 )
self.Weapon:SetNWString( "BobSway", 0.5 )
end
end

function SWEP:Think()
if self.Reloading == 1 then
if self.Weapon:Clip1() > 0 then
if self.ReloadingTimer < CurTime() + 1.5 and self.ReloadingTimer > CurTime() + 1.25 then
self.Owner:ViewPunch( Angle( 0, 0.05, 0 ) )
end
if self.ReloadingTimer < CurTime() + 1.25 and self.ReloadingTimer > CurTime() + 1 then
self.Owner:ViewPunch( Angle( 0, 0, 0.05 ) )
end
if self.ReloadingTimer < CurTime() + 1 and self.ReloadingTimer > CurTime() + 0.75 then
self.Owner:ViewPunch( Angle( 0.05, -0.05, 0 ) )
end
if self.ReloadingTimer < CurTime() + 0.75 and self.ReloadingTimer > CurTime() + 0.5 then
self.Owner:ViewPunch( Angle( 0.05, 0.05, -0.05 ) )
end
if self.ReloadingTimer < CurTime() + 0.5 and self.ReloadingTimer > CurTime() + 0.25 then
self.Owner:ViewPunch( Angle( 0.05, 0, 0 ) )
end
if self.ReloadingTimer < CurTime() + 0.25 then
self.Owner:ViewPunch( Angle( 0, 0, 0.05 ) )
end
end
if self.Weapon:Clip1() <= 0 then
if self.ReloadingTimer < CurTime() + 2.61 and self.ReloadingTimer > CurTime() + 2.25 then
self.Owner:ViewPunch( Angle( 0, 0.05, 0 ) )
end
if self.ReloadingTimer < CurTime() + 2.25 and self.ReloadingTimer > CurTime() + 2 then
self.Owner:ViewPunch( Angle( 0, 0, 0.05 ) )
end
if self.ReloadingTimer < CurTime() + 2 and self.ReloadingTimer > CurTime() + 1.75 then
self.Owner:ViewPunch( Angle( 0.05, -0.05, 0 ) )
end
if self.ReloadingTimer < CurTime() + 1.75 and self.ReloadingTimer > CurTime() + 1.5 then
self.Owner:ViewPunch( Angle( 0.05, 0.05, -0.05 ) )
end
if self.ReloadingTimer < CurTime() + 1.5 and self.ReloadingTimer > CurTime() + 1.25 then
self.Owner:ViewPunch( Angle( 0.05, 0, 0 ) )
end
if self.ReloadingTimer < CurTime() + 1.25 and self.ReloadingTimer > CurTime() + 1 then
self.Owner:ViewPunch( Angle( 0, 0, 0.05 ) )
end
if self.ReloadingTimer < CurTime() + 1 and self.ReloadingTimer > CurTime() + 0.75 then
self.Owner:ViewPunch( Angle( 0, 0.05, -0.05 ) )
end
if self.ReloadingTimer < CurTime() + 0.75 and self.ReloadingTimer > CurTime() + 0.5 then
self.Owner:ViewPunch( Angle( 0.05, 0, 0 ) )
end
if self.ReloadingTimer < CurTime() + 0.5 and self.ReloadingTimer > CurTime() + 0.25 then
self.Owner:ViewPunch( Angle( 0, 0, 0.05 ) )
end
if self.ReloadingTimer < CurTime() + 0.25 then
self.Owner:ViewPunch( Angle( 0.05, 0, 0 ) )
end
end
end
self.SwayScale = self.Weapon:GetNWString( "BobSway", 0.5 )
self.BobScale = self.Weapon:GetNWString( "BobSway", 0.5 )
if self.Sprint == 0 then
if self.Bob == 0 and ( self.Owner:KeyDown( IN_FORWARD ) || self.Owner:KeyDown( IN_BACK ) || self.Owner:KeyDown( IN_MOVELEFT ) || self.Owner:KeyDown( IN_MOVERIGHT ) ) then
self.BobTimer = CurTime()
self.Bob = 1
end
if self.BobTimer <= CurTime() and self.Bob == 1 then
self.Owner:ViewPunch( Angle( 0.1, -0.1, -0.1 ) )
self.BobTimer = CurTime() + 0.3
self.Bob = 2
end
if self.BobTimer <= CurTime() and self.Bob == 2 then
self.Owner:ViewPunch( Angle( 0.1, 0.1, 0.1 ) )
self.BobTimer = CurTime() + 0.3
self.Bob = 1
end
if !( self.Owner:KeyDown( IN_FORWARD ) || self.Owner:KeyDown( IN_BACK ) || self.Owner:KeyDown( IN_MOVELEFT ) || self.Owner:KeyDown( IN_MOVERIGHT ) ) then
self.BobTimer = CurTime()
self.Bob = 0
end
end
if self.Reloading == 0 then
if self.Sprint == 0 and self.Owner:KeyDown( IN_SPEED ) and ( self.Owner:KeyDown( IN_FORWARD ) || self.Owner:KeyDown( IN_BACK ) || self.Owner:KeyDown( IN_MOVELEFT ) || self.Owner:KeyDown( IN_MOVERIGHT ) ) then
if SERVER then
self.Weapon:SendWeaponAnim( ACT_VM_SPRINT_IDLE )
end
self.Iron = 0
self.Sprint = 1
self.Bob = 1
self.BobTimer = CurTime()
self.Attack = 0
self.Idle = 0
self.IdleTimer = CurTime()
self.Owner:SetFOV( 0, self.IronOutTime )
self.Owner:SetWalkSpeed( 200 )
self.Weapon:SetNWString( "BobSway", 0.5 )
end
if self.Sprint == 1 and self.BobTimer <= CurTime() and self.Bob == 1 then
self.Owner:ViewPunch( Angle( 0.5, -0.5, -0.5 ) )
self.BobTimer = CurTime() + 0.3
self.Bob = 2
end
if self.Sprint == 1 and self.BobTimer <= CurTime() and self.Bob == 2 then
self.Owner:ViewPunch( Angle( 0.5, 0.5, 0.5 ) )
self.BobTimer = CurTime() + 0.3
self.Bob = 1
end
if self.Sprint == 1 and !self.Owner:KeyDown( IN_SPEED ) then
if SERVER then
self.Weapon:SendWeaponAnim( ACT_VM_IDLE )
end
if self.Chamber == 0 then
self:SetNextPrimaryFire( CurTime() + 0.2 )
self:SetNextSecondaryFire( CurTime() + 0.2 )
end
if self.Chamber == 1 then
self:SetNextPrimaryFire( CurTime() + self.Primary.DelayChamber )
self:SetNextSecondaryFire( CurTime() + self.Primary.DelayChamber )
end
self.Sprint = 0
self.BobTimer = CurTime()
self.Bob = 0
self.Idle = 0
self.IdleTimer = CurTime() + 0.2
end
if self.Sprint == 1 and !( self.Owner:KeyDown( IN_FORWARD ) || self.Owner:KeyDown( IN_BACK ) || self.Owner:KeyDown( IN_MOVELEFT ) || self.Owner:KeyDown( IN_MOVERIGHT ) ) then
if SERVER then
self.Weapon:SendWeaponAnim( ACT_VM_IDLE )
end
if self.Chamber == 0 then
self:SetNextPrimaryFire( CurTime() + 0.2 )
self:SetNextSecondaryFire( CurTime() + 0.2 )
end
if self.Chamber == 1 then
self:SetNextPrimaryFire( CurTime() + self.Primary.DelayChamber )
self:SetNextSecondaryFire( CurTime() + self.Primary.DelayChamber )
end
self.Sprint = 0
self.Bob = 0
self.BobTimer = CurTime()
self.Idle = 0
self.IdleTimer = CurTime() + 0.2
end
end
if self.Idle == 0 and self.IdleTimer > CurTime() and self.IdleTimer < CurTime() + 0.1 then
if SERVER and self.Sprint == 0 and self.Reloading == 0 then
if self.Iron == 0 then
self.Weapon:SendWeaponAnim( ACT_VM_IDLE )
if self.Chamber == 1 then
self.Weapon:SendWeaponAnim( ACT_VM_RELOAD_DEPLOYED )
self:SetNextPrimaryFire( CurTime() + self.Primary.DelayChamber )
self:SetNextSecondaryFire( CurTime() + self.Primary.DelayChamber )
self.Idle = 0
self.IdleTimer = CurTime() + 1
self.Chamber = 0
end
end
if self.Iron == 1 then
self.Weapon:SendWeaponAnim( ACT_VM_IDLE_DEPLOYED )
if self.Chamber == 1 then
self.Weapon:SendWeaponAnim( ACT_VM_PRIMARYATTACK_DEPLOYED_1 )
self:SetNextPrimaryFire( CurTime() + self.Primary.DelayChamber )
self:SetNextSecondaryFire( CurTime() + self.Primary.DelayChamber )
self.Idle = 0
self.IdleTimer = CurTime() + 1
self.Chamber = 0
end
end
end
self.Idle = 1
end
if self.Reloading == 1 and self.ReloadingTimer <= CurTime() then
if self.Weapon:Ammo1() > ( self.Primary.ClipSize - self.Weapon:Clip1() ) then
self.Owner:SetAmmo( self.Weapon:Ammo1() - self.Primary.ClipSize + self.Weapon:Clip1(), self.Primary.Ammo )
self.Weapon:SetClip1( self.Primary.ClipSize )
end
if ( self.Weapon:Ammo1() - self.Primary.ClipSize + self.Weapon:Clip1() ) + self.Weapon:Clip1() < self.Primary.ClipSize then
self.Weapon:SetClip1( self.Weapon:Clip1() + self.Weapon:Ammo1() )
self.Owner:SetAmmo( 0, self.Primary.Ammo )
end
self.Reloading = 0
end
if self.Weapon:Ammo1() > self.Primary.MaxAmmo then
self.Owner:SetAmmo( self.Primary.MaxAmmo, self.Primary.Ammo )
end
end