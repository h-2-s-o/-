player_manager.AddValidModel( "Hopson", "models/player/hopson.mdl" )
player_manager.AddValidHands( "Hopson", "models/player/hopsonHands.mdl", 0, "00000000" )