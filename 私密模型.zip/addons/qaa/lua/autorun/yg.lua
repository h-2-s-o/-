player_manager.AddValidModel( "Hopson", "models/yg/ygg.mdl" )
player_manager.AddValidHands( "Hopson", "models/player/hopsonHands.mdl", 0, "00000000" )