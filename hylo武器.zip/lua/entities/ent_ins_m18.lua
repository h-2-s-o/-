AddCSLuaFile()
ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.Spawnable = false

function ENT:Draw()
self.Entity:DrawModel()
end

function ENT:Initialize()
if SERVER then
self.Entity:SetModel( "models/ins/weapons/w_gren_m18.mdl" )
self.Entity:SetMoveType( MOVETYPE_VPHYSICS )
self.Entity:SetSolid( SOLID_VPHYSICS )
self.Entity:PhysicsInit( SOLID_VPHYSICS )
self.Entity:SetCollisionGroup( COLLISION_GROUP_WEAPON )
self.Entity:DrawShadow( false )
self.Explode = 0
self.ExplodeTimer = CurTime() + 2
end
end

function ENT:Think()
if SERVER and self.Explode == 0 then
for i = 0, ( 5 ) do
smoke = ents.Create( "env_smoketrail" )
smoke:SetKeyValue( "startsize", "8" )
smoke:SetKeyValue( "endsize", "5" )
smoke:SetKeyValue( "spawnradius", "4" )
smoke:SetKeyValue( "opacity", "1" )
smoke:SetKeyValue( "spawnrate", "5" )
smoke:SetKeyValue( "lifetime", "0.5" )
smoke:SetPos( self:GetPos() )
smoke:SetParent( self.Entity )
smoke:Spawn()
smoke:Fire( "kill", "", 0.5 )
end
end
if self.Explode == 0 and self.ExplodeTimer <= CurTime() then
if SERVER then
self.Entity:EmitSound( "BaseSmokeEffect.Sound" )
for i = 0, ( 5 ) do
smoke = ents.Create( "env_smoketrail" )
smoke:SetKeyValue( "startsize", "640" )
smoke:SetKeyValue( "endsize", "512" )
smoke:SetKeyValue( "spawnradius", "196" )
smoke:SetKeyValue( "opacity", "1" )
smoke:SetKeyValue( "spawnrate", "10" )
smoke:SetKeyValue( "lifetime", "20" )
smoke:SetPos( self:GetPos() )
smoke:SetParent( self.Entity )
smoke:Spawn()
smoke:Fire( "kill", "", 20 )
end
end
self.Explode = 1
end
end

function ENT:PhysicsCollide()
if SERVER then
self.Entity:EmitSound( "Grenade_INS.Bounce" )
end
end