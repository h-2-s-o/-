AddCSLuaFile()

ENT.Type 			= "anim"
ENT.Base 			= "base_gmodentity"
ENT.PrintName		= "Pink Points"
ENT.Author			= "Xaxidoro"
ENT.Information		= ""
ENT.Category		= "Touhou"

ENT.Spawnable		= true
ENT.AdminSpawnable	= true

/*---------------------------------------------------------
   Name: DrawPre
---------------------------------------------------------*/
function ENT:Draw()
	
	self.Entity:DrawModel()
end

function ENT:Think()

end

if SERVER then
	/*---------------------------------------------------------
	   Name: Initialize
	---------------------------------------------------------*/
	function ENT:Initialize()

		// Use the helibomb model just for the shadow (because it's about the same size)
		self.Entity:SetModel("models/touhou/item_square.mdl")
		self.Entity:PhysicsInit(SOLID_VPHYSICS)
		self.Entity:SetMoveType(MOVETYPE_VPHYSICS)
		self.Entity:SetSolid(SOLID_VPHYSICS)
		self.Entity:DrawShadow(false)
		
		self.Entity:SetCollisionGroup(COLLISION_GROUP_INTERACTIVE_DEBRIS)
		
		local phys = self.Entity:GetPhysicsObject()
		
		if (phys:IsValid()) then
			phys:Wake()
		end

		--self.Entity:SetUseType(SIMPLE_USE)
	end

	function ENT:Touch( ent )
		if ent:IsValid() and ent:IsPlayer() then
			 
			ent:EmitSound("weapons/yuuka/MISS.wav")
			ent:SetHealth( ent:Health() + 20 )
			self:Remove()
		end
	end

	/*---------------------------------------------------------
	   Name: PhysicsCollide
	---------------------------------------------------------*/
	function ENT:PhysicsCollide(data, physobj)
		
	end
end

/*---------------------------------------------------------
   Name: OnTakeDamage
---------------------------------------------------------*/
function ENT:OnTakeDamage(dmginfo)

	self.Entity:TakePhysicsDamage(dmginfo)
	
end


/*---------------------------------------------------------
   Name: Use
---------------------------------------------------------*/
function ENT:Use(activator, caller)

end