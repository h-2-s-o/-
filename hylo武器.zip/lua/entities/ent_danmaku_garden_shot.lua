AddCSLuaFile()

ENT.Type = "anim"

ENT.Base = "base_gmodentity"
ENT.PrintName = ""
ENT.Spawnable = false

ENT.Author = "Xaxidoro"

ENT.AdminSpawnable = false

if SERVER then 

	ENT.LifeTime = nil
	ENT.dmg = nil

	function ENT:Initialize()
		self.Entity:SetModel("models/Touhou/oval_2.mdl")
		self.Entity:SetSkin( 3 )

		self.Entity:PhysicsInit(SOLID_VPHYSICS)
		self.Entity:SetMoveType(MOVETYPE_VPHYSICS)
		self.Entity:SetSolid(SOLID_VPHYSICS)
		self.Entity:SetCollisionGroup(COLLISION_GROUP_IN_VEHICLE)
		self.Entity:SetTrigger( true )
		self.Entity:DrawShadow( false )

		local phys = self.Entity:GetPhysicsObject()
		if(phys:IsValid()) then 
			--phys:SetMaterial( "gmod_bouncy" )
			phys:SetMass( 100 )
			phys:EnableDrag( false )
			phys:SetDragCoefficient( 0 )
			phys:EnableGravity( false )
			phys:Wake() 
		end
		self.LifeTime = CurTime() + 3
		self.dmg = DamageInfo()
			self.dmg:SetDamage( 100 )
			self.dmg:SetDamageType( DMG_AIRBOAT )
			self.dmg:SetAttacker( self.Owner )
			self.dmg:SetInflictor( self.Entity )
	end

	function ENT:Touch( entity ) 
		if not entity:IsValid() then return end
		if entity == self.Owner then return end
		if string.find(entity:GetClass(), "ent_danmaku_garden") then return end
		if string.find(entity:GetClass(), "ent_touhou_points") then return end
		
		self.dmg:SetDamageForce( self.Entity:GetVelocity():GetNormalized() * 10 )
		entity:TakeDamageInfo( self.dmg )
	
		if entity:GetOwner():IsValid() then
			if entity:GetOwner() ~= entity then
				entity:GetOwner():TakeDamageInfo(self.dmg)
			end
		end
		
		self:Explosion()
	end
	
	function ENT:Think()
		if self.LifeTime < CurTime() then
			self:Explosion()
		end
	end

	function ENT:Explosion()
		self.Entity:Remove()
	end

	function Pichuun(npc, attacker, inflictor)
		if !attacker:IsValid() or !attacker:IsPlayer() then return end
		
		local Wep = attacker:GetActiveWeapon()
		if !IsValid( Wep ) then return end
		if !Wep:IsWeapon() then return end
		if !Wep.MadCow then return end
		if !( Wep:GetWeaponViewModel() == "models/weapons/c_yuuka_garden.mdl" ) then return end
		npc:EmitSound("weapons/yuuka/DEAD.wav")
	end
	hook.Add( "OnNPCKilled", "danmaku_garden_shot_pichuun", Pichuun );
	
end

if CLIENT then
	function ENT:Initialize()

	end

	function ENT:Draw()
		self.Entity:DrawModel()
	end

	function ENT:Think()

	end
end 