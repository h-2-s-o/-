AddCSLuaFile()
ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.Spawnable = false

function ENT:Draw()
self.Entity:DrawModel()
end

function ENT:Initialize()
if SERVER then
self.Entity:SetModel( "models/ins/weapons/w_gren_m67.mdl" )
self.Entity:SetMoveType( MOVETYPE_VPHYSICS )
self.Entity:SetSolid( SOLID_VPHYSICS )
self.Entity:PhysicsInit( SOLID_VPHYSICS )
self.Entity:SetCollisionGroup( COLLISION_GROUP_WEAPON )
self.Entity:DrawShadow( false )
self.ExplodeTimer = CurTime() + 4
end
end

function ENT:Think()
if SERVER then
for i = 0, ( 5 ) do
smoke = ents.Create( "env_smoketrail" )
smoke:SetKeyValue( "startsize", "8" )
smoke:SetKeyValue( "endsize", "5" )
smoke:SetKeyValue( "spawnradius", "4" )
smoke:SetKeyValue( "opacity", "1" )
smoke:SetKeyValue( "spawnrate", "5" )
smoke:SetKeyValue( "lifetime", "0.5" )
smoke:SetPos( self:GetPos() )
smoke:SetParent( self.Entity )
smoke:Spawn()
smoke:Fire( "kill", "", 0.5 )
end
if self.ExplodeTimer <= CurTime() then
self.Entity:Remove()
end
end
end

function ENT:PhysicsCollide()
if SERVER then
self.Entity:EmitSound( "Grenade_INS.Bounce" )
end
end

function ENT:OnRemove()
if SERVER then
local explode = ents.Create( "env_explosion" )
explode:SetOwner( self.Owner )
explode:SetPos( self:GetPos() )
explode:Spawn()
explode:Fire( "Explode", 0, 0 )
end
util.BlastDamage( self, self.Owner, self:GetPos(), 512, 150 )
end