AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

if SERVER then
	function SWEP:Bomb()
		local k, v
		local dmg = DamageInfo()
			dmg:SetDamage(99999999)
			dmg:SetDamageType(DMG_DISSOLVE)
			dmg:SetAttacker(self.Owner)
			dmg:SetInflictor(self.Owner)
			
		self.Owner:EmitSound("weapons/yuuka/BOMB.wav")
		
		for i=1, 8 do
			local sparks = ents.Create( "env_spark" )
				sparks:SetPos( self.Owner:GetPos() + Vector( math.random( -40, 40 ), math.random( -40, 40 ), math.random( -40, 40 ) ) )
				sparks:SetKeyValue( "MaxDelay", "0" )
				sparks:SetKeyValue( "Magnitude", "2" )
				sparks:SetKeyValue( "TrailLength", "3" )
				sparks:SetKeyValue( "spawnflags", "0" )
				sparks:Spawn()
				sparks:Fire( "SparkOnce", "", 0 )
		end
		local explosioneffect = ents.Create( "prop_combine_ball" )
			explosioneffect:SetPos(self.Owner:GetPos())
			explosioneffect:Spawn()
			explosioneffect:Fire( "explode", "", 0 )
		
		for k, v in pairs ( ents.FindInSphere( self.Owner:GetPos(), 500 ) ) do
			if v:IsValid() and v != self.Owner and not string.find(v:GetClass(), "ent_touhou_points") then
				dmg:SetDamageForce( ( v:GetPos() - self.Owner:GetPos() ) * 500 )
				v:TakeDamageInfo( dmg )
			end	
		end
	end
	function SWEP:Shock( attacker, entity, n )
		if entity:IsValid() then
			n = n + 1
			
			local effect = EffectData()
			effect:SetEntity(entity)
			effect:SetMagnitude(30)
			effect:SetScale(30)
			effect:SetRadius(30)
			util.Effect("TeslaHitBoxes", effect)
			
			local dmginfo = DamageInfo()
				dmginfo:SetDamage(2 + math.Rand(1,3))
				dmginfo:SetAttacker( attacker )
				dmginfo:SetInflictor( attacker )
			entity:TakeDamageInfo( dmginfo )
			
			entity:EmitSound("Weapon_StunStick.Activate")
			
			if n <= 9 then
				timer.Simple((math.random(8,20)/100), function() self:Shock( attacker, entity, n ) end )
			end
		end
	end
end