PrecacheParticleSystem( "utaunt_hearts_beams" )

-- For Grazing
SWEP.YuukaGarden = true
SWEP.MadCow				= true

if (SERVER) then

	AddCSLuaFile( "shared.lua" )
	SWEP.Weight				= 5
	SWEP.AutoSwitchTo			= false
	SWEP.AutoSwitchFrom		= false

end

if ( CLIENT ) then
	SWEP.PrintName			= "Garden Parasol"
	SWEP.Author				= "Xaxidoro"
	SWEP.DrawAmmo 			= false
	SWEP.DrawCrosshair 		= false
	SWEP.ViewModelFOV			= 56
	SWEP.ViewModelFlip		= false
	SWEP.CSMuzzleFlashes		= false
	
	SWEP.Slot				= 1
	SWEP.SlotPos			= 1
	SWEP.IconLetter			= "E"

	killicon.Add( "weapon_mad_garden", "HUD/killicons/default", Color( 255, 80, 0, 255 ) )
end


SWEP.Base 						= "weapon_mad_base_melee"
SWEP.Category					= "Touhou"

SWEP.Spawnable					= true
SWEP.AdminSpawnable				= true

SWEP.ViewModel 					= "models/weapons/c_yuuka_garden.mdl"
SWEP.WorldModel 				= "models/weapons/w_yuuka_garden.mdl"
SWEP.UseHands 					= true

SWEP.Weight						= 5
SWEP.AutoSwitchTo				= false
SWEP.AutoSwitchFrom				= false
SWEP.HoldType = "melee"

SWEP.Primary.Anim				= ACT_VM_MISSCENTER
SWEP.Primary.SwingAngle			= -35
SWEP.Primary.MeleeSweep			= 25
SWEP.Primary.Damage				= 34
SWEP.Primary.NumShots			= 5 -- * 2 + 1
SWEP.Primary.Delay 				= 0.4
SWEP.Primary.ClipSize			= -1
SWEP.Primary.DefaultClip		= -1
SWEP.Primary.Automatic			= true
SWEP.Primary.Ammo				= "none"


SWEP.Secondary.Delay 			= 0.5
SWEP.Secondary.Anim				= ACT_VM_HITCENTER
SWEP.Secondary.SwingAngle		= 90
SWEP.Secondary.MeleeSweep		= 0
SWEP.Secondary.NumShots			= 0 -- * 2 + 1
SWEP.Secondary.Damage			= 100
SWEP.Secondary.ClipSize			= -1
SWEP.Secondary.DefaultClip		= -1
SWEP.Secondary.Automatic		= true
SWEP.Secondary.Ammo				= "AR2AltFire"

SWEP.Pistol						= true
SWEP.Rifle						= false
SWEP.Shotgun					= false
SWEP.Sniper						= false

SWEP.MeleeRange					= 130

SWEP.MissSound 				= Sound("weapons/iceaxe/iceaxe_swing1.wav")
SWEP.HitSound				= Sound("physics/wood/wood_plank_impact_hard4.wav")
SWEP.WallSound 				= Sound("physics/wood/wood_plank_impact_hard4.wav")
SWEP.CriticalSound			= Sound("physics/wood/wood_plank_impact_hard4.wav")
SWEP.DeploySound			= Sound("weapons/stunstick/alyx_stunner1.wav")

SWEP.Grazing 				= false
SWEP.GrazeTime				= CurTime()
SWEP.TickTime				= CurTime()
SWEP.BombTime				= CurTime()
SWEP.FlyTime				= CurTime()
SWEP.FiringTime				= CurTime()

SWEP.RunArmOffset 			= Vector(0,0,-6)
SWEP.RunArmAngle 			= Vector(0,-20,0)

SWEP.HoldingPos = Vector(0,-10,-20)
SWEP.HoldingAng = Vector(0,90,0)

/*---------------------------------------------------------
   Name: SWEP:OnRemove()
   Desc: Get rid of tails and shite
---------------------------------------------------------*/
function SWEP:OnRemove()
	if IsValid( self.Owner ) then
		self.Owner:StopParticles()
	end
end
function SWEP:Holster()
	self:OnRemove()
	return true
end
function SWEP:OnDrop()
	self:OnRemove()
end

/*---------------------------------------------------------
   Name: SWEP:SecondThink()
   Desc: Called every frame. Use this function if you don't 
	   want to copy/past the think function everytime you 
	   create a new weapon with this base...
---------------------------------------------------------*/
function SWEP:SecondThink()
	if self.TickTime <= CurTime() then
		self.TickTime = CurTime() + 0.5
		if self.GrazeTime >= CurTime() then
			ParticleEffectAttach( "utaunt_hearts_beams", PATTACH_ABSORIGIN_FOLLOW, self.Owner, 0 )
		else
			self.Owner:StopParticles()
		end
	end
end

function SWEP:Bomb()

end

/*---------------------------------------------------------
   Name: SWEP:Reload()
   Desc: Parry
---------------------------------------------------------*/
function SWEP:Reload()
	if not IsFirstTimePredicted() then return end

	if self.Owner:KeyDown(IN_USE) and self.BombTime < CurTime() and self:Ammo2() > 0 then
		self.BombTime = CurTime() + 3
		self.GrazeTime = CurTime() + 5
		self:TakeSecondaryAmmo( 1 )
		self.Grazing = true
		
		self.Weapon:SendWeaponAnim(ACT_VM_DRAW)
		self.Weapon:EmitSound(self.MissSound)
		timer.Simple(2.5, function() 
			self.Grazing = false 
		end )
		self:Bomb()
	end
	
	if self.Grazing then return end
	
	self.Grazing = true
	self.GrazeTime = CurTime() + 3
	
	self.Weapon:EmitSound(self.MissSound)
	self.Weapon:SetNextPrimaryFire(CurTime() + 0.7)
	
	timer.Simple(0.1, function() 
		self.Weapon:SendWeaponAnim(ACT_VM_DRAW) --ACT_VM_HITRIGHT
		self.Owner:GetViewModel():SetPlaybackRate(0.7)
	end )
	timer.Simple(0.9, function() 
		self.Grazing = false 
		self.Owner:GetViewModel():SetPlaybackRate(1)
	end )
end

/*---------------------------------------------------------
   Name: SWEP:Think()
   Desc: Called every frame.
---------------------------------------------------------*/
function SWEP:Think()

	self:SecondThink()

	if not self.Owner:IsOnGround() then
		if self.Owner:KeyDown( IN_JUMP ) and self.FlyTime < CurTime() and IsFirstTimePredicted() then
			self.FlyTime = CurTime() + 0.3
			--self.Owner:EmitSound( "weapons/physcannon/energy_sing_flyby2.wav" )
			if self.Owner:KeyDown( IN_FORWARD ) then
				self.Owner:SetVelocity( self.Owner:GetAimVector() * 300 + physenv.GetGravity():GetNormalized() * -100 )
			elseif self.Owner:KeyDown( IN_BACK ) then
				self.Owner:SetVelocity( self.Owner:GetAimVector() * -300 + physenv.GetGravity():GetNormalized() * -100 )
			elseif self.Owner:KeyDown( IN_MOVELEFT ) then
				self.Owner:SetVelocity( self.Owner:GetRight() * -300 + physenv.GetGravity():GetNormalized() * -100 )
			elseif self.Owner:KeyDown( IN_MOVERIGHT ) then
				self.Owner:SetVelocity( self.Owner:GetRight() * 300 + physenv.GetGravity():GetNormalized() * -100 )
			else
				self.Owner:SetVelocity( physenv.GetGravity():GetNormalized() * -400 )
			end
		end
	elseif IsFirstTimePredicted() then
		self.FlyTime = CurTime()
	end
	
	self:NextThink(CurTime())
	
end


function SWEP:Graze( target, dmg )
	if target == self.Owner then
		if self.GrazeTime > CurTime() then
			
			--dmg:GetDamageForce():Mul( -1 )
			--dmg:SetDamageType( DMG_AIRBOAT )
			--dmg:GetInflictor():TakeDamageInfo( dmg )
			self.Weapon:EmitSound( "weapons/yuuka/MISS.wav" )
			dmg:ScaleDamage( 0 )
			dmg:GetDamageForce():Mul( 0 )
			
			local effectdata = EffectData()
				effectdata:SetOrigin(self.Owner:GetPos())
				effectdata:SetEntity(self.Owner)
				effectdata:SetStart(self.Owner:GetPos())
				effectdata:SetNormal(Vector(0,0,1))
			local sparkeffect = effectdata
				sparkeffect:SetMagnitude(3)
				sparkeffect:SetRadius(8)
				sparkeffect:SetScale(5)
				util.Effect("Sparks", sparkeffect)
		end
	end
end

function YuukaTouhouGraze(target, dmg)

	if !target:IsValid() or !target:IsPlayer() then return end
	
	local Wep = target:GetActiveWeapon()
	if !IsValid( Wep ) then return end
	if !Wep:IsWeapon() then return end
	if !Wep.MadCow or !Wep.YuukaGarden then return end
	if !( Wep:GetWeaponViewModel() == "models/weapons/c_yuuka_garden.mdl" ) then return end
	
	if dmg:GetDamageType() == DMG_FALL then
		dmg:SetDamage( 0 )
		return
	end
	
	Wep:Graze( target, dmg )

end
hook.Add( "EntityTakeDamage", "YuukaTouhouGraze", YuukaTouhouGraze );

function YuukaGivePoints(npc, attacker, inflictor)
	if !attacker:IsValid() or !attacker:IsPlayer() then return end
	
	local Wep = attacker:GetActiveWeapon()
	if !IsValid( Wep ) then return end
	if !Wep:IsWeapon() then return end
	if !Wep.MadCow or !Wep.YuukaGarden then return end
	if !( Wep:GetWeaponViewModel() == "models/weapons/c_yuuka_garden.mdl" ) then return end
	
	local pos = npc:GetPos()
		pos = pos + npc:GetUp() * 50
	
	npc:EmitSound( "weapons/yuuka/DEAD.wav" )
	
	for i=1, 7 do
		local pointNum = math.random() * 100
		local points
		
		if pointNum < 5 then
			points = ents.Create("ent_touhou_points_pink")
		elseif pointNum < 10 then
			points = ents.Create("ent_touhou_points_green")
		elseif pointNum < 40 then
			points = ents.Create("ent_touhou_points_red")
		else
			points = ents.Create("ent_touhou_points_blue")
		end
		
		points:SetPos(pos)

		points:Spawn()
		points:Activate()

		local phys = points:GetPhysicsObject()
		phys:SetVelocity( Vector( 500 * ( math.random() - 0.5 ), 500 * ( math.random() - 0.5 ) , 500 * ( math.random() - 0.5 ) ) )
	end
	
end
hook.Add( "OnNPCKilled", "YuukaGivePoints", YuukaGivePoints );

/*---------------------------------------------------------
   Name: SWEP:SecondaryAttack()
   Desc: +attack2 has been pressed.
---------------------------------------------------------*/
function SWEP:SecondaryAttack()

	if self.FiringTime > CurTime() then
		self.MasterSpark(self)
		return
	end
	if (not self.Owner:IsNPC() and self.Owner:KeyDown(IN_USE)) then
		if self.Weapon:GetDTBool(0) --[[ or self.Owner:KeyDown(IN_SPEED) --]] then return end
		self.Weapon:ESecondary()
		return
	end

	if self.Weapon:GetDTBool(0) or self.Owner:KeyDown(IN_SPEED) then return end

	self.Weapon:SetNextPrimaryFire(CurTime() + self.Secondary.Delay + self.Secondary.SwingTime)
	self.Weapon:SetNextSecondaryFire(CurTime() + self.Secondary.Delay + self.Secondary.SwingTime)
	self.Owner:SetAnimation(PLAYER_ATTACK1)

	self:SecondaryAnim()
	
	if self.Secondary.SwingTime <= 0 then
		self:SecondaryAttackFilter()
		return
	end
	timer.Simple( self.Secondary.SwingTime, function() self:SecondaryAttackFilter() end )
	
end

/*---------------------------------------------------------
   Name: SWEP:SecondaryAttackFilter()
   Desc: +attack2 has been pressed, and everything else has been processed
---------------------------------------------------------*/
function SWEP:SecondaryAttackFilter()

	self.Weapon:EmitSound(self.MissSound,100,math.random(90,120))
		
	--if trace.Entity:GetClass() == "func_door_rotating" or trace.Entity:GetClass() == "prop_door_rotating" then return end
	
	bullet = {}
	bullet.Num    = 1
	bullet.Src    = self.Owner:GetShootPos()
	bullet.Dir    = self.Owner:GetAimVector()
	bullet.Spread = Vector(0, 0, 0)
	bullet.Tracer = 0
	bullet.Force  = 10
	bullet.HullSize = 15
	bullet.Damage = self.Secondary.Damage
	bullet.Distance = self.MeleeRange
	bullet.AmmoType = "357"
	bullet.Callback	= function(attacker, tr, dmginfo) 
		if self.HitSoundPlayed then return end
		if tr.Entity:IsValid() then
			self:SecondaryOnHit(attacker, tr, dmginfo)
			self.Weapon:EmitSound(self.CriticalSound)
			self.HitSoundPlayed = true
		else
			self.Weapon:EmitSound(self.WallSound)
		end
	end
	self.Owner:FireBullets(bullet)

	if ((game.SinglePlayer() and SERVER) or CLIENT) then
		self.Weapon:SetNetworkedFloat("LastShootTime", CurTime())
	end

	self:IdleAnimation(1)
	self.HitSoundPlayed = false
end

function SWEP:ESecondary()
	
	self.Weapon:EmitSound("weapons/yuuka/POWERUP.wav")
	
	self.Weapon:SendWeaponAnim(ACT_VM_MISSCENTER)
	self.Owner:GetViewModel():SetPlaybackRate(0.06)
	
	self.Weapon:SetNextSecondaryFire(CurTime() + 1.4)
	self.Weapon:SetNextPrimaryFire(CurTime() + 2) --3.35
	
	if CLIENT then return end
	
	timer.Simple(1.35, function() self.MasterSpark(self) end)

end

function SWEP:MasterSpark()

	self.FiringTime = CurTime() + 0.15
	self.Weapon:SetNextSecondaryFire(CurTime() + 0.1)
	--if not (self.Charging) then return end
	if (!self.Weapon) or (!self.Weapon:IsValid()) then return end
	if (!self.Owner) or (!self.Owner:Alive()) then return end

	local pp = self.Owner:GetShootPos() 
	local tr = self.Owner:GetEyeTrace()
	
	local dist = (tr.HitPos - pp):Length()
	local delay = dist/8000
	
	self.Weapon:SendWeaponAnim(ACT_VM_DRAW)
		
	self.Weapon:EmitSound("weapons/yuuka/LASER.wav")
	
	if (SERVER) then
		for i=1, 4 do
			timer.Simple(0.02 * i, function()
				local spell = ents.Create("ent_danmaku_garden_shot")
				spell:SetAngles(self.Owner:EyeAngles())

				local pos = self.Owner:GetShootPos()
					pos = pos + self.Owner:GetForward() * 5
					pos = pos + self.Owner:GetRight() * 9
					pos = pos + self.Owner:GetUp() * -5
				spell:SetPos(pos)

				spell:SetOwner(self.Owner)
				spell:SetPhysicsAttacker(self.Owner)
				spell:Spawn()
				spell:Activate()

				local phys = spell:GetPhysicsObject()
				phys:SetVelocity(self.Owner:GetAimVector() * 99999999)
			end)
		end
		
	end
	
	--play animations
	self.Weapon:SendWeaponAnim(ACT_VM_SECONDARYATTACK)
	self.Owner:MuzzleFlash()
	self.Owner:SetAnimation(PLAYER_ATTACK1)
	
	--apply recoil
	self.Owner:ViewPunch( Angle(math.Rand(-1,-0.5),math.Rand(-0.5,0.5), 0))
	
	timer.Simple(delay,function() self.Disintegrate(self,tr) end)

end

function SWEP:Disintegrate(tr)

	self.GrazeTime = CurTime() + 0.2
	
	local fx = EffectData()
	fx:SetEntity(self.Owner)
	fx:SetOrigin(tr.HitPos)
	fx:SetNormal(tr.HitNormal)
	util.Effect("stridcan_expld",fx)
	
	if CLIENT then return end

	local splodepos = tr.HitPos + 3*tr.HitNormal
	
	local dmg = DamageInfo()
	dmg:SetDamage( 25 )
	dmg:SetDamageType( DMG_DISSOLVE )
	dmg:SetAttacker( self.Owner )
	dmg:SetInflictor( self.Weapon )
	
	local en = ents.FindInSphere(splodepos, 350)
	
	local vaporizer = ents.Create("point_hurt")
	vaporizer:SetKeyValue("Damage",0)
	vaporizer:EmitSound("Weapon_Mortar.Impact")
	vaporizer:SetPos(splodepos)

	for k, v in pairs(en) do
		if v:IsValid() and v != self.Owner and not string.find(v:GetClass(), "ent_touhou_points") then
			dmg:SetDamageForce( ( v:GetPos() - splodepos ):GetNormalized() * 99999 )
			v:TakeDamageInfo( dmg )
		end
	end
	
	if not tr.Entity:IsValid() then return end
	if tr.Entity then
	
		dmg:SetDamageForce( ( tr.HitPos - self.Owner:GetShootPos() ) * 99999 )
		tr.Entity:TakeDamageInfo(dmg)
		
		dmg:SetDamageType( DMG_AIRBOAT )
		tr.Entity:TakeDamageInfo(dmg)
		
		tr.Entity:TakeDamage( 25, self.Owner, self.Weapon )
		
		if tr.Entity:GetOwner():IsValid() then
			if tr.Entity:GetOwner() ~= tr.Entity then
				tr.Entity:TakeDamageInfo(dmg)
			end
		end
	end

end

function SWEP:Shock( attacker, entity, n )
end