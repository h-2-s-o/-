if CLIENT then
SWEP.WepSelectIcon = surface.GetTextureID( "ins/hud/wpnselect/icons/weapon_m18" )
SWEP.DrawWeaponInfoBox	= false
SWEP.BounceWeaponIcon = false
killicon.Add( "weapon_ins_m18", "ins/hud/wpnselect/icons/weapon_m18", Color( 255, 255, 255, 255 ) )
killicon.Add( "ent_ins_m18", "ins/hud/wpnselect/icons/weapon_m18", Color( 255, 255, 255, 255 ) )
end

SWEP.PrintName = "M18 SMOKE GRENADE"
SWEP.Category = "Insurgency: Modern Infantry Combat"
SWEP.Spawnable= true
SWEP.AdminSpawnable= true
SWEP.AdminOnly = false

SWEP.ViewModelFOV = 65
SWEP.ViewModel = "models/ins/weapons/v_gren_m18.mdl"
SWEP.WorldModel = "models/ins/weapons/w_gren_m18.mdl"
SWEP.ViewModelFlip = false
SWEP.BobScale = 1
SWEP.SwayScale = 1

SWEP.AutoSwitchTo = false
SWEP.AutoSwitchFrom = false
SWEP.Weight = 0
SWEP.Slot = 4
SWEP.SlotPos = 0

SWEP.UseHands = false
SWEP.HoldType = "grenade"
SWEP.FiresUnderwater = true
SWEP.DrawCrosshair = false
SWEP.DrawAmmo = true
SWEP.CSMuzzleFlashes = 1
SWEP.Base = "weapon_base"

SWEP.Throw = 0
SWEP.ThrowTimer = CurTime()
SWEP.Sprint = 0
SWEP.Bob = 0
SWEP.BobTimer = CurTime()
SWEP.Idle = 0
SWEP.IdleTimer = CurTime()

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = 1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "Grenade"
SWEP.Primary.TakeAmmo = 1
SWEP.Primary.Delay = 0.75
SWEP.Primary.Force = 1

SWEP.Secondary.ClipSize = 0
SWEP.Secondary.DefaultClip = 0
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

function SWEP:Initialize()
self:SetWeaponHoldType( self.HoldType )
self.Idle = 0
self.IdleTimer = CurTime() + 0.5
end

function SWEP:Deploy()
self:SetWeaponHoldType( self.HoldType )
self.Weapon:SendWeaponAnim( ACT_VM_DRAW )
self:SetNextPrimaryFire( CurTime() + 0.5 )
self:SetNextSecondaryFire( CurTime() + 0.5 )
self.Throw = 0
self.ThrowTimer = CurTime()
self.Sprint = 0
self.Bob = 0
self.BobTimer = CurTime()
self.Idle = 0
self.IdleTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
if self.Weapon:Ammo1() <= 0 then
if SERVER then
self.Owner:DropWeapon( self.Weapon )
end
self.Weapon:Remove()
end
return true
end

function SWEP:Holster()
self.Throw = 0
self.ThrowTimer = CurTime()
self.Sprint = 0
self.Bob = 0
self.BobTimer = CurTime()
self.Idle = 0
self.IdleTimer = CurTime()
if self.Weapon:Ammo1() <= 0 then
if SERVER then
self.Owner:DropWeapon( self.Weapon )
end
self.Weapon:Remove()
end
return true
end

function SWEP:PrimaryAttack()
if !( self.Throw == 0 ) then return end
if self.Sprint == 1 then return end
if self.Weapon:Ammo1() <= 0 then return end
self.Weapon:SendWeaponAnim( ACT_VM_PULLBACK_HIGH )
self:SetNextPrimaryFire( CurTime() + self.Primary.Delay )
self:SetNextSecondaryFire( CurTime() + self.Primary.Delay )
self.Throw = 1
self.ThrowTimer = CurTime() + 0.75
self.Idle = 1
end

function SWEP:SecondaryAttack()
if !( self.Throw == 0 ) then return end
if self.Sprint == 1 then return end
if self.Weapon:Ammo1() <= 0 then return end
self.Weapon:SendWeaponAnim( ACT_VM_PULLBACK_LOW )
self:SetNextPrimaryFire( CurTime() + self.Primary.Delay )
self:SetNextSecondaryFire( CurTime() + self.Primary.Delay )
self.Throw = 3
self.ThrowTimer = CurTime() + 0.75
self.Idle = 1
end

function SWEP:Reload()
end

function SWEP:Think()
if !self.Owner:KeyDown( IN_ATTACK ) and self.Throw == 1 and self.ThrowTimer <= CurTime() then
if SERVER then
local entity = ents.Create( "ent_ins_m18" )
entity:SetOwner( self.Owner )
if IsValid( entity ) then
local Forward = self.Owner:EyeAngles():Forward()
local Right = self.Owner:EyeAngles():Right()
local Up = self.Owner:EyeAngles():Up()
entity:SetPos( self.Owner:GetShootPos() + Forward * 4 + Right * 8 + Up * 0 )
entity:SetAngles( self.Owner:EyeAngles() )
entity:Spawn()
local phys = entity:GetPhysicsObject()
phys:SetVelocity( self.Owner:GetAimVector() * 1000 )
end
end
self.Weapon:SendWeaponAnim( ACT_VM_PRIMARYATTACK )
self.Owner:SetAnimation( PLAYER_ATTACK1 )
self:TakePrimaryAmmo( self.Primary.TakeAmmo )
self.Throw = 2
self.ThrowTimer = CurTime() + 0.5
self.Idle = 0
self.IdleTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
end
if !self.Owner:KeyDown( IN_ATTACK2 ) and self.Throw == 3 and self.ThrowTimer <= CurTime() then
if SERVER then
local entity = ents.Create( "ent_ins_m18" )
entity:SetOwner( self.Owner )
if IsValid( entity ) then
local Forward = self.Owner:EyeAngles():Forward()
local Right = self.Owner:EyeAngles():Right()
local Up = self.Owner:EyeAngles():Up()
entity:SetPos( self.Owner:GetShootPos() + Forward * 4 + Right * 8 + Up * 0 )
entity:SetAngles( self.Owner:EyeAngles() )
entity:Spawn()
local phys = entity:GetPhysicsObject()
phys:SetVelocity( self.Owner:GetAimVector() * 500 )
end
end
self.Weapon:SendWeaponAnim( ACT_VM_SECONDARYATTACK )
self.Owner:SetAnimation( PLAYER_ATTACK1 )
self:TakePrimaryAmmo( self.Primary.TakeAmmo )
self.Throw = 2
self.ThrowTimer = CurTime() + 0.5
self.Idle = 0
self.IdleTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
end
if self.Throw == 2 and self.ThrowTimer <= CurTime() and self.Weapon:Ammo1() > 0 then
self.Weapon:SendWeaponAnim( ACT_VM_DRAW )
self:SetNextPrimaryFire( CurTime() + 0.5 )
self:SetNextSecondaryFire( CurTime() + 0.5 )
self.Throw = 0
self.ThrowTimer = CurTime()
self.Idle = 0
self.IdleTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
end
if self.Sprint == 0 then
if self.Bob == 0 and ( self.Owner:KeyDown( IN_FORWARD ) || self.Owner:KeyDown( IN_BACK ) || self.Owner:KeyDown( IN_MOVELEFT ) || self.Owner:KeyDown( IN_MOVERIGHT ) ) then
self.BobTimer = CurTime()
self.Bob = 1
end
if self.Bob == 1 and self.BobTimer <= CurTime() then
self.Owner:ViewPunch( Angle( -0.1, -0.15, -0.05 ) )
self.BobTimer = CurTime() + 0.2
self.Bob = 2
end
if self.Bob == 2 and self.BobTimer <= CurTime() then
self.Owner:ViewPunch( Angle( 0.05, 0, 0 ) )
self.BobTimer = CurTime() + 0.2
self.Bob = 3
end
if self.Bob == 3 and self.BobTimer <= CurTime() then
self.Owner:ViewPunch( Angle( -0.1, 0.15, 0.05 ) )
self.BobTimer = CurTime() + 0.2
self.Bob = 4
end
if self.Bob == 4 and self.BobTimer <= CurTime() then
self.Owner:ViewPunch( Angle( 0.05, 0, 0 ) )
self.BobTimer = CurTime() + 0.2
self.Bob = 1
end
if !( self.Owner:KeyDown( IN_FORWARD ) || self.Owner:KeyDown( IN_BACK ) || self.Owner:KeyDown( IN_MOVELEFT ) || self.Owner:KeyDown( IN_MOVERIGHT ) ) then
self.BobTimer = CurTime()
self.Bob = 0
end
end
if self.Throw == 0 and self.ThrowTimer <= CurTime() then
if self.Sprint == 0 and self.Owner:KeyDown( IN_SPEED ) and ( self.Owner:KeyDown( IN_FORWARD ) || self.Owner:KeyDown( IN_BACK ) || self.Owner:KeyDown( IN_MOVELEFT ) || self.Owner:KeyDown( IN_MOVERIGHT ) ) then
if SERVER then
self.Weapon:SendWeaponAnim( ACT_VM_SPRINT_IDLE )
end
self.Sprint = 1
self.Bob = 1
self.BobTimer = CurTime()
self.Idle = 0
self.IdleTimer = CurTime()
end
if self.Sprint == 1 then
if self.Bob == 1 and self.BobTimer <= CurTime() then
self.Owner:ViewPunch( Angle( -0.2, -0.3, -0.1 ) )
self.BobTimer = CurTime() + 0.2
self.Bob = 2
end
if self.Bob == 2 and self.BobTimer <= CurTime() then
self.Owner:ViewPunch( Angle( 0.1, 0, 0 ) )
self.BobTimer = CurTime() + 0.2
self.Bob = 3
end
if self.Bob == 3 and self.BobTimer <= CurTime() then
self.Owner:ViewPunch( Angle( -0.2, 0.3, 0.1 ) )
self.BobTimer = CurTime() + 0.2
self.Bob = 4
end
if self.Bob == 4 and self.BobTimer <= CurTime() then
self.Owner:ViewPunch( Angle( 0.1, 0, 0 ) )
self.BobTimer = CurTime() + 0.2
self.Bob = 1
end
if !self.Owner:KeyDown( IN_SPEED ) then
if SERVER then
self.Weapon:SendWeaponAnim( ACT_VM_IDLE )
end
self:SetNextPrimaryFire( CurTime() + 0.2 )
self:SetNextSecondaryFire( CurTime() + 0.2 )
self.Sprint = 0
self.BobTimer = CurTime()
self.Bob = 0
self.Idle = 0
self.IdleTimer = CurTime() + 0.2
end
if !( self.Owner:KeyDown( IN_FORWARD ) || self.Owner:KeyDown( IN_BACK ) || self.Owner:KeyDown( IN_MOVELEFT ) || self.Owner:KeyDown( IN_MOVERIGHT ) ) then
if SERVER then
self.Weapon:SendWeaponAnim( ACT_VM_IDLE )
end
self:SetNextPrimaryFire( CurTime() + 0.2 )
self:SetNextSecondaryFire( CurTime() + 0.2 )
self.Sprint = 0
self.Bob = 0
self.BobTimer = CurTime()
self.Idle = 0
self.IdleTimer = CurTime() + 0.2
end
end
end
if self.Idle == 0 and self.IdleTimer <= CurTime() then
if SERVER and self.Sprint == 0 and self.Throw == 0 then
self.Weapon:SendWeaponAnim( ACT_VM_IDLE )
end
self.Idle = 1
end
if self.Throw == 2 and self.ThrowTimer <= CurTime() and self.Weapon:Ammo1() <= 0 then
if SERVER then
self.Owner:DropWeapon( self.Weapon )
end
self.Weapon:Remove()
end
end