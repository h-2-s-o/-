if CLIENT then
SWEP.WepSelectIcon = surface.GetTextureID( "ins/hud/wpnselect/icons/weapon_rpg7" )
SWEP.DrawWeaponInfoBox	= false
SWEP.BounceWeaponIcon = false
killicon.Add( "weapon_ins_rpg7", "ins/hud/wpnselect/icons/weapon_rpg7", Color( 255, 255, 255, 255 ) )
killicon.Add( "ent_ins_rpg7_projectile", "ins/hud/wpnselect/icons/weapon_rpg7", Color( 255, 255, 255, 255 ) )
end

SWEP.PrintName = "RPG-7"
SWEP.Category = "Insurgency: Modern Infantry Combat"
SWEP.Spawnable= true
SWEP.AdminSpawnable= true
SWEP.AdminOnly = false

SWEP.ViewModelFOV = 65
SWEP.ViewModel = "models/ins/weapons/v_at_rpg7.mdl"
SWEP.WorldModel = "models/ins/weapons/w_at_rpg7.mdl"
SWEP.ViewModelFlip = false
SWEP.BobScale = 1
SWEP.SwayScale = 1

SWEP.AutoSwitchTo = false
SWEP.AutoSwitchFrom = false
SWEP.Weight = 20
SWEP.Slot = 3
SWEP.SlotPos = 0

SWEP.UseHands = false
SWEP.HoldType = "rpg"
SWEP.FiresUnderwater = true
SWEP.DrawCrosshair = false
SWEP.DrawAmmo = true
SWEP.CSMuzzleFlashes = 1
SWEP.Base = "weapon_base"

SWEP.FirstTime = 0
SWEP.Iron = 0
SWEP.Reloading = 0
SWEP.ReloadingTimer = CurTime()
SWEP.ReloadingTime = 3
SWEP.Sprint = 0
SWEP.Bob = 0
SWEP.BobTimer = CurTime()
SWEP.Idle = 0
SWEP.IdleTimer = CurTime()

SWEP.Primary.Sound = Sound( "Weapon_INS_RPG7.Single" )
SWEP.Primary.ClipSize = 1
SWEP.Primary.DefaultClip = 1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "RPG_Round"
SWEP.Primary.TakeAmmo = 1
SWEP.Primary.Delay = 0.5
SWEP.Primary.Force = 1

SWEP.Secondary.ClipSize = 0
SWEP.Secondary.DefaultClip = 0
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

function SWEP:Initialize()
self:SetWeaponHoldType( self.HoldType )
self.FirstTime = 1
self.Idle = 0
self.IdleTimer = CurTime() + 0.5
end

function SWEP:Deploy()
self:SetWeaponHoldType( self.HoldType )
if self.FirstTime == 0 then
if self.Weapon:Clip1() > 0 then
self.Weapon:SendWeaponAnim( ACT_VM_DRAW )
end
if self.Weapon:Clip1() <= 0 then
self.Weapon:SendWeaponAnim( ACT_VM_DRAW_EMPTY )
end
self:SetNextPrimaryFire( CurTime() + 0.75 )
self:SetNextSecondaryFire( CurTime() + 0.75 )
self.ReloadingTimer = CurTime() + 0.75
end
if self.FirstTime == 1 then
self.Weapon:SendWeaponAnim( ACT_DEPLOY )
self:SetNextPrimaryFire( CurTime() + 4 )
self:SetNextSecondaryFire( CurTime() + 4 )
self.ReloadingTimer = CurTime() + 4
end
self.FirstTime = 0
self.Iron = 0
self.Reloading = 0
self.Sprint = 0
self.Bob = 0
self.BobTimer = CurTime()
self.Idle = 0
self.IdleTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
self.Owner:SetWalkSpeed( 200 )
self.Weapon:SetNWString( "BobSway", 1 )
return true
end

function SWEP:Holster()
self.Iron = 0
self.Reloading = 0
self.ReloadingTimer = CurTime()
self.Sprint = 0
self.Bob = 0
self.BobTimer = CurTime()
self.Idle = 0
self.IdleTimer = CurTime()
self.Owner:SetWalkSpeed( 200 )
self.Weapon:SetNWString( "BobSway", 1 )
return true
end

function SWEP:PrimaryAttack()
if self.Reloading == 1 then return end
if self.Sprint == 1 then return end
if self.Weapon:Clip1() <= 0 then
if SERVER then
self.Owner:EmitSound( "Weapon_INS_RPG7.Empty" )
end
self:SetNextPrimaryFire( CurTime() + 0.2 )
end
if self.FiresUnderwater == false and self.Owner:WaterLevel() == 3 then
if SERVER then
self.Owner:EmitSound( "Weapon_INS_RPG7.Empty" )
end
self:SetNextPrimaryFire( CurTime() + 0.2 )
end
if self.Weapon:Clip1() <= 0 then return end
if self.FiresUnderwater == false and self.Owner:WaterLevel() == 3 then return end
if SERVER then
local entity = ents.Create( "ent_ins_rpg7_projectile" )
entity:SetOwner( self.Owner )
if IsValid( entity ) then
local Forward = self.Owner:EyeAngles():Forward()
local Right = self.Owner:EyeAngles():Right()
local Up = self.Owner:EyeAngles():Up()
if self.Iron == 0 then
entity:SetPos( self.Owner:GetShootPos() + Forward * 4 + Right * 8 + Up * -4 )
end
if self.Iron == 1 then
entity:SetPos( self.Owner:GetShootPos() + Forward * 4 + Up * -4 )
end
entity:SetAngles( self.Owner:EyeAngles() )
entity:Spawn()
local phys = entity:GetPhysicsObject()
phys:SetVelocity( self.Owner:GetAimVector() * 999999 )
end
end
self:ShootEffects()
self:TakePrimaryAmmo( self.Primary.TakeAmmo )
self:SetNextPrimaryFire( CurTime() + self.Primary.Delay )
self:SetNextSecondaryFire( CurTime() + self.Primary.Delay )
self.Idle = 0
self.IdleTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
end

function SWEP:ShootEffects()
self:EmitSound( self.Primary.Sound )
if SERVER then
self.Owner:EmitSound( "Weapon_INS_RPG7.Echo" )
end
if self.Iron == 0 then
self.Weapon:SendWeaponAnim( ACT_VM_PRIMARYATTACK )
end
if self.Iron == 1 then
self.Weapon:SendWeaponAnim( ACT_VM_PRIMARYATTACK_DEPLOYED )
end
self.Owner:SetAnimation( PLAYER_ATTACK1 )
self.Owner:MuzzleFlash()
self.Owner:ViewPunchReset()
self.Owner:ViewPunch( Angle( -0.2, math.Rand( -0.1, 0.1 ), 0 ) )
end

function SWEP:SecondaryAttack()
if self.Reloading == 1 then return end
if self.Sprint == 1 then return end
if self.Iron == 0 then
if self.Weapon:Clip1() > 0 then
self.Weapon:SendWeaponAnim( ACT_VM_DEPLOY )
end
if self.Weapon:Clip1() <= 0 then
self.Weapon:SendWeaponAnim( ACT_VM_DEPLOY_EMPTY )
end
self:SetNextPrimaryFire( CurTime() + 0.25 )
self:SetNextSecondaryFire( CurTime() + 0.25 )
self.Iron = 1
self.Idle = 0
self.IdleTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
self.Owner:SetFOV( 75, 0.2 )
self.Owner:SetWalkSpeed( 100 )
self.Weapon:SetNWString( "BobSway", 0.1 )
else
if self.Iron == 1 then
if self.Weapon:Clip1() > 0 then
self.Weapon:SendWeaponAnim( ACT_VM_UNDEPLOY )
end
if self.Weapon:Clip1() <= 0 then
self.Weapon:SendWeaponAnim( ACT_VM_UNDEPLOY_EMPTY )
end
self:SetNextPrimaryFire( CurTime() + 0.25 )
self:SetNextSecondaryFire( CurTime() + 0.25 )
self.Iron = 0
self.Idle = 0
self.IdleTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
self.Owner:SetFOV( 0, 0.2 )
self.Owner:SetWalkSpeed( 200 )
self.Weapon:SetNWString( "BobSway", 1 )
end
end
end

function SWEP:Reload()
if self.Reloading == 0 and self.ReloadingTimer <= CurTime() and self.Weapon:Clip1() <= 0 and self.Weapon:Ammo1() > 0 then
self.Weapon:SendWeaponAnim( ACT_VM_RELOAD )
self.Owner:SetAnimation( PLAYER_RELOAD )
self:SetNextPrimaryFire( CurTime() + self.Owner:GetViewModel():SequenceDuration() )
self:SetNextSecondaryFire( CurTime() + self.Owner:GetViewModel():SequenceDuration() )
self.Iron = 0
self.Sprint = 0
self.Bob = 0
self.BobTimer = CurTime()
self.Reloading = 1
self.ReloadingTimer = CurTime() + self.ReloadingTime
self.Idle = 0
self.IdleTimer = CurTime() + self.Owner:GetViewModel():SequenceDuration()
self.Owner:SetFOV( 0, 0.2 )
self.Owner:SetWalkSpeed( 200 )
self.Weapon:SetNWString( "BobSway", 1 )
end
end

function SWEP:Think()
self.BobScale = self.Weapon:GetNWString( "BobSway", 1 )
self.SwayScale = self.Weapon:GetNWString( "BobSway", 1 )
if self.Sprint == 0 then
if self.Bob == 0 and ( self.Owner:KeyDown( IN_FORWARD ) || self.Owner:KeyDown( IN_BACK ) || self.Owner:KeyDown( IN_MOVELEFT ) || self.Owner:KeyDown( IN_MOVERIGHT ) ) then
self.BobTimer = CurTime()
self.Bob = 1
end
if self.Bob == 1 and self.BobTimer <= CurTime() then
self.Owner:ViewPunch( Angle( -0.1, -0.15, -0.05 ) )
self.BobTimer = CurTime() + 0.2
self.Bob = 2
end
if self.Bob == 2 and self.BobTimer <= CurTime() then
self.Owner:ViewPunch( Angle( 0.05, 0, 0 ) )
self.BobTimer = CurTime() + 0.2
self.Bob = 3
end
if self.Bob == 3 and self.BobTimer <= CurTime() then
self.Owner:ViewPunch( Angle( -0.1, 0.15, 0.05 ) )
self.BobTimer = CurTime() + 0.2
self.Bob = 4
end
if self.Bob == 4 and self.BobTimer <= CurTime() then
self.Owner:ViewPunch( Angle( 0.05, 0, 0 ) )
self.BobTimer = CurTime() + 0.2
self.Bob = 1
end
if !( self.Owner:KeyDown( IN_FORWARD ) || self.Owner:KeyDown( IN_BACK ) || self.Owner:KeyDown( IN_MOVELEFT ) || self.Owner:KeyDown( IN_MOVERIGHT ) ) then
self.BobTimer = CurTime()
self.Bob = 0
end
end
if self.Reloading == 0 and self.ReloadingTimer <= CurTime() then
if self.Sprint == 0 and self.Owner:KeyDown( IN_SPEED ) and ( self.Owner:KeyDown( IN_FORWARD ) || self.Owner:KeyDown( IN_BACK ) || self.Owner:KeyDown( IN_MOVELEFT ) || self.Owner:KeyDown( IN_MOVERIGHT ) ) then
if SERVER then
if self.Weapon:Clip1() > 0 then
self.Weapon:SendWeaponAnim( ACT_VM_SPRINT_IDLE )
end
if self.Weapon:Clip1() <= 0 then
self.Weapon:SendWeaponAnim( ACT_VM_SPRINT_LEAVE )
end
end
self.Iron = 0
self.Sprint = 1
self.Bob = 1
self.BobTimer = CurTime()
self.Idle = 0
self.IdleTimer = CurTime()
self.Owner:SetFOV( 0, 0.2 )
self.Owner:SetWalkSpeed( 200 )
self.Weapon:SetNWString( "BobSway", 1 )
end
if self.Sprint == 1 then
if self.Bob == 1 and self.BobTimer <= CurTime() then
self.Owner:ViewPunch( Angle( -0.2, -0.3, -0.1 ) )
self.BobTimer = CurTime() + 0.2
self.Bob = 2
end
if self.Bob == 2 and self.BobTimer <= CurTime() then
self.Owner:ViewPunch( Angle( 0.1, 0, 0 ) )
self.BobTimer = CurTime() + 0.2
self.Bob = 3
end
if self.Bob == 3 and self.BobTimer <= CurTime() then
self.Owner:ViewPunch( Angle( -0.2, 0.3, 0.1 ) )
self.BobTimer = CurTime() + 0.2
self.Bob = 4
end
if self.Bob == 4 and self.BobTimer <= CurTime() then
self.Owner:ViewPunch( Angle( 0.1, 0, 0 ) )
self.BobTimer = CurTime() + 0.2
self.Bob = 1
end
if !self.Owner:KeyDown( IN_SPEED ) then
if SERVER then
if self.Weapon:Clip1() > 0 then
self.Weapon:SendWeaponAnim( ACT_VM_IDLE )
end
if self.Weapon:Clip1() <= 0 then
self.Weapon:SendWeaponAnim( ACT_VM_IDLE_EMPTY )
end
end
self:SetNextPrimaryFire( CurTime() + 0.2 )
self:SetNextSecondaryFire( CurTime() + 0.2 )
self.Sprint = 0
self.BobTimer = CurTime()
self.Bob = 0
self.Idle = 0
self.IdleTimer = CurTime() + 0.2
self.Weapon:SetNWString( "Crosshair", true )
end
if !( self.Owner:KeyDown( IN_FORWARD ) || self.Owner:KeyDown( IN_BACK ) || self.Owner:KeyDown( IN_MOVELEFT ) || self.Owner:KeyDown( IN_MOVERIGHT ) ) then
if SERVER then
if self.Weapon:Clip1() > 0 then
self.Weapon:SendWeaponAnim( ACT_VM_IDLE )
end
if self.Weapon:Clip1() <= 0 then
self.Weapon:SendWeaponAnim( ACT_VM_IDLE_EMPTY )
end
end
self:SetNextPrimaryFire( CurTime() + 0.2 )
self:SetNextSecondaryFire( CurTime() + 0.2 )
self.Sprint = 0
self.Bob = 0
self.BobTimer = CurTime()
self.Idle = 0
self.IdleTimer = CurTime() + 0.2
self.Weapon:SetNWString( "Crosshair", true )
end
end
end
if self.Idle == 0 and self.IdleTimer <= CurTime() then
if SERVER and self.Sprint == 0 and self.Reloading == 0 then
if self.Iron == 0 then
if self.Weapon:Clip1() > 0 then
self.Weapon:SendWeaponAnim( ACT_VM_IDLE )
end
if self.Weapon:Clip1() <= 0 then
self.Weapon:SendWeaponAnim( ACT_VM_IDLE_EMPTY )
end
end
if self.Iron == 1 then
if self.Weapon:Clip1() > 0 then
self.Weapon:SendWeaponAnim( ACT_VM_IDLE_DEPLOYED )
end
if self.Weapon:Clip1() <= 0 then
self.Weapon:SendWeaponAnim( ACT_VM_IDLE_DEPLOYED_EMPTY )
end
end
end
self.Idle = 1
end
if self.Reloading == 1 and self.ReloadingTimer <= CurTime() then
if self.Weapon:Ammo1() > ( self.Primary.ClipSize - self.Weapon:Clip1() ) then
self.Owner:SetAmmo( self.Weapon:Ammo1() - self.Primary.ClipSize + self.Weapon:Clip1(), self.Primary.Ammo )
self.Weapon:SetClip1( self.Primary.ClipSize )
end
if ( self.Weapon:Ammo1() - self.Primary.ClipSize + self.Weapon:Clip1() ) + self.Weapon:Clip1() < self.Primary.ClipSize then
self.Weapon:SetClip1( self.Weapon:Clip1() + self.Weapon:Ammo1() )
self.Owner:SetAmmo( 0, self.Primary.Ammo )
end
self.Reloading = 0
end
end