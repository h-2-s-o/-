SWEP.Base 			= "weapon_mad_base"
SWEP.MadCow = true

SWEP.UseHands = true

SWEP.Spawnable				= false
SWEP.AdminSpawnable			= false

SWEP.ViewModel				= ""
SWEP.WorldModel				= ""

SWEP.Weight					= 5
SWEP.AutoSwitchTo				= false
SWEP.AutoSwitchFrom			= false
SWEP.HoldType = "knife"

SWEP.Primary.Delay 				= 0.5
SWEP.Primary.Anim				= ACT_VM_MISSCENTER
SWEP.Primary.SwingTime			= 0
SWEP.Primary.SwingAngle			= 0
SWEP.Primary.MeleeSweep			= 30
SWEP.Primary.NumShots			= 3 -- * 2 + 1
SWEP.Primary.Damage				= 35
SWEP.Primary.ClipSize			= -1
SWEP.Primary.DefaultClip		= -1
SWEP.Primary.Automatic			= true
SWEP.Primary.Ammo				= "none"

SWEP.Secondary.Delay 			= 1
SWEP.Secondary.Anim				= ACT_VM_SWINGHARD
SWEP.Secondary.SwingTime		= 0
SWEP.Secondary.SwingAngle		= 90
SWEP.Secondary.MeleeSweep		= 40
SWEP.Secondary.NumShots			= 0 -- * 2 + 1
SWEP.Secondary.Damage			= 55
SWEP.Secondary.Backstab			= 99999999
SWEP.Secondary.ClipSize			= -1
SWEP.Secondary.DefaultClip		= -1
SWEP.Secondary.Automatic		= false
SWEP.Secondary.Ammo				= "none"

SWEP.MeleeRange			= 60

SWEP.Pistol				= true
SWEP.Rifle				= false
SWEP.Shotgun			= false
SWEP.Sniper				= false

SWEP.HitSound				= Sound("Weapon_Knife.Hit")
SWEP.CriticalSound			= Sound("Weapon_Knife.Stab")
SWEP.MissSound 				= Sound("weapons/knife/knife_slash1.wav")
SWEP.WallSound 				= Sound("weapons/knife/knife_hitwall1.wav")
SWEP.DeploySound			= nil
SWEP.HitSoundPlayed			= false

SWEP.RunArmOffset = Vector(0,0,-6)
SWEP.RunArmAngle = Vector(0,0,0)

SWEP.HoldingPos = Vector(0,0,0)

function SWEP:DrawHUD()

end

function SWEP:Shock( attacker, entity, n )
end

/*---------------------------------------------------------
Initialize
---------------------------------------------------------*/
function SWEP:Initialize()

	self:SetWeaponHoldType(self.HoldType) 	-- Hold type of the 3rd person animation
end

/*---------------------------------------------------------
   Name: SWEP:Deploy()
---------------------------------------------------------*/
function SWEP:Deploy()

	self.Weapon:SendWeaponAnim(ACT_VM_DRAW)
	self.Weapon:SetNextPrimaryFire(CurTime() + 1)

	if self.DeploySound then
		self.Weapon:EmitSound(self.DeploySound, 50, 100)
	end

	self:IdleAnimation(1)

	return true
end

function SWEP:SecondaryAnim()
	self.Weapon:SendWeaponAnim(self.Secondary.Anim)
end

/*---------------------------------------------------------
   Name: SWEP:SecondaryAttack()
   Desc: +attack2 has been pressed.
---------------------------------------------------------*/
function SWEP:SecondaryAttack()
	
	if not IsFirstTimePredicted() then return end

	// Holst/Deploy your fucking weapon
	if (not self.Owner:IsNPC() and self.Owner:KeyDown(IN_USE)) then
		if self.Weapon:GetDTBool(0) or self.Owner:KeyDown(IN_SPEED) then return end
			self.Weapon:ESecondary()
		return
	end

	if self.Weapon:GetDTBool(0) --[[or self.Owner:KeyDown(IN_SPEED)--]] then return end

	self.Weapon:SetNextPrimaryFire(CurTime() + self.Secondary.Delay + self.Secondary.SwingTime)
	self.Weapon:SetNextSecondaryFire(CurTime() + self.Secondary.Delay + self.Secondary.SwingTime)
	self.Owner:SetAnimation(PLAYER_ATTACK1)

	self:SecondaryAnim()
	
	if self.Secondary.SwingTime <= 0 then
		self:SecondaryAttackFilter()
		return
	end
	timer.Simple( self.Secondary.SwingTime, function() self:SecondaryAttackFilter() end )
	
end

/*---------------------------------------------------------
   Name: SWEP:ESecondary()
   Desc: +attack2+E has been pressed.
---------------------------------------------------------*/
function SWEP:ESecondary()
	
end

function SWEP:SecondaryOnHit(attacker, tr, dmginfo)

end
	
/*---------------------------------------------------------
   Name: SWEP:SecondaryAttackFilter()
   Desc: +attack2 has been pressed, and everything else has been processed
---------------------------------------------------------*/
function SWEP:SecondaryAttackFilter()

	self.Weapon:EmitSound(self.MissSound,100,math.random(90,120))
		
	--if trace.Entity:GetClass() == "func_door_rotating" or trace.Entity:GetClass() == "prop_door_rotating" then return end
	if CLIENT then return end
	
	bullet = {}
	bullet.Num    = 1
	bullet.Src    = self.Owner:GetShootPos()
	bullet.Dir    = self.Owner:GetAimVector()
	bullet.Spread = Vector(0, 0, 0)
	bullet.Tracer = 0
	bullet.Force  = 10
	bullet.Damage = self.Secondary.Damage
	bullet.Distance = self.MeleeRange
	bullet.AmmoType = "pistol"
	bullet.Callback	= function(attacker, tr, dmginfo) 
		if self.HitSoundPlayed then return end
		if tr.Entity:IsValid() then
			self:SecondaryOnHit(attacker, tr, dmginfo)
			self.Weapon:EmitSound(self.CriticalSound)
			self.HitSoundPlayed = true
		else
			self.Weapon:EmitSound(self.WallSound)
		end
	end
	self.Owner:FireBullets(bullet)
	
	local swingAngle = self.Owner:GetUp():Angle()
	swingAngle:RotateAroundAxis( self.Owner:GetAimVector(), self.Secondary.SwingAngle )
	
	if self.Secondary.NumShots > 0 then
		for i = -1, self.Secondary.NumShots * 2 - 2 do
		
			local aim = self.Owner:GetAimVector():Angle()
			aim:RotateAroundAxis( swingAngle:Forward(), self.Secondary.MeleeSweep - 2 * self.Secondary.MeleeSweep * i / self.Secondary.NumShots )
			local aimVector = aim:Forward()
			
			bullet = {}
			bullet.Num    = 1
			bullet.Src    = self.Owner:GetShootPos()
			bullet.Dir    = aimVector
			bullet.Spread = Vector(0, 0, 0)
			bullet.Tracer = 0
			bullet.Force  = 10
			bullet.Damage = self.Secondary.Damage
			bullet.Distance = self.MeleeRange
			bullet.AmmoType = "pistol"
			bullet.Callback	= function(attacker, tr, dmginfo) 
				if self.HitSoundPlayed then return end
				if tr.Entity:IsValid() then
					self:SecondaryOnHit(attacker, tr, dmginfo)
					self.Weapon:EmitSound(self.CriticalSound)
					self.HitSoundPlayed = true
				else
					self.Weapon:EmitSound(self.WallSound)
				end
			end
			self.Owner:FireBullets(bullet)
		end
	end

	if ((game.SinglePlayer() and SERVER) or CLIENT) then
		self.Weapon:SetNetworkedFloat("LastShootTime", CurTime())
	end

	self:IdleAnimation(1)
	self.HitSoundPlayed = false
end

function SWEP:PrimaryAnim()
	self.Weapon:SendWeaponAnim(self.Primary.Anim)
end

/*---------------------------------------------------------
   Name: SWEP:PrimaryAttack()
   Desc: +attack1 has been pressed.
---------------------------------------------------------*/
function SWEP:PrimaryAttack()

	if not IsFirstTimePredicted() then return end
	
	// Holst/Deploy your fucking weapon
	if (not self.Owner:IsNPC() and self.Owner:KeyDown(IN_USE)) then
		bHolsted = !self.Weapon:GetDTBool(0)
		self:SetHolsted(bHolsted)

		self.Weapon:SetNextPrimaryFire(CurTime() + 0.3)
		self.Weapon:SetNextSecondaryFire(CurTime() + 0.3)

		self:SetIronsights(false)

		return
	end
	
	if self.Weapon:GetDTBool(0) --[[or self.Owner:KeyDown(IN_SPEED)--]] then return end

	self.Weapon:SetNextPrimaryFire(CurTime() + self.Primary.Delay + self.Primary.SwingTime)
	self.Weapon:SetNextSecondaryFire(CurTime() + self.Primary.Delay + self.Primary.SwingTime)
	self.Owner:SetAnimation(PLAYER_ATTACK1)

	self:PrimaryAnim()
	
	if self.Primary.SwingTime <= 0 then
		self:PrimaryAttackFilter()
		return
	end
	timer.Simple( self.Primary.SwingTime, function() self:PrimaryAttackFilter() end )
	
end

function SWEP:PrimaryOnHit(attacker, tr, dmginfo)

end

function SWEP:PrimaryAttackFilter()

	self.Weapon:EmitSound(self.MissSound,100,math.random(90,120))
	
	if CLIENT then return end
	
	bullet = {}
	bullet.Num    = 1
	bullet.Src    = self.Owner:GetShootPos()
	bullet.Dir    = self.Owner:GetAimVector()
	bullet.Spread = Vector(0, 0, 0)
	bullet.Tracer = 0
	bullet.Force  = 10
	bullet.Damage = self.Primary.Damage
	bullet.Distance = self.MeleeRange
	bullet.AmmoType = "pistol"			
	bullet.Callback	= function(attacker, tr, dmginfo) 
		if self.HitSoundPlayed then return end
		if tr.Entity:IsValid() then
			self:PrimaryOnHit(attacker, tr, dmginfo)
			self.Weapon:EmitSound(self.HitSound)
			self.HitSoundPlayed = true
		else
			self.Weapon:EmitSound(self.WallSound)
		end
	end
	self.Owner:FireBullets(bullet)
	
	local swingAngle = self.Owner:GetUp():Angle()
	swingAngle:RotateAroundAxis( self.Owner:GetAimVector(), self.Primary.SwingAngle )
	
	if self.Primary.NumShots > 0 then
		for i = -1, self.Primary.NumShots * 2 - 2 do
		
			local aim = self.Owner:GetAimVector():Angle()
			aim:RotateAroundAxis( swingAngle:Forward(), self.Primary.MeleeSweep - 2 * self.Primary.MeleeSweep * i / self.Primary.NumShots )
			local aimVector = aim:Forward()
			
			bullet = {}
			bullet.Num    = 1
			bullet.Src    = self.Owner:GetShootPos()
			bullet.Dir    = aimVector
			bullet.Spread = Vector(0, 0, 0)
			bullet.Tracer = 0
			bullet.Force  = 10
			bullet.Damage = self.Primary.Damage
			bullet.Distance = self.MeleeRange
			bullet.IgnoreEntity = game.GetWorld()
			bullet.AmmoType = "pistol"
			bullet.Callback	= function(attacker, tr, dmginfo) 
				if self.HitSoundPlayed then return end
				if tr.Entity:IsValid() then
					self:PrimaryOnHit(attacker, tr, dmginfo)
					self.Weapon:EmitSound(self.HitSound)
					self.HitSoundPlayed = true
				else
					self.Weapon:EmitSound(self.WallSound)
				end
			end
			self.Owner:FireBullets(bullet)
		end
	end

	if ((game.SinglePlayer() and SERVER) or CLIENT) then
		self.Weapon:SetNetworkedFloat("LastShootTime", CurTime())
	end

	self:IdleAnimation(1)
	self.HitSoundPlayed = false

end

/*---------------------------------------------------------
Reload
---------------------------------------------------------*/
function SWEP:Reload()
	return false

end

/*---------------------------------------------------------
ShootEffects
---------------------------------------------------------*/
function SWEP:ShootEffects()
end

function SWEP:IronSight()
end

/*---------------------------------------------------------
SetIronsights
---------------------------------------------------------*/
function SWEP:SetIronsights(b)
	self.Weapon:SetNetworkedBool("Ironsights", b)
end

function SWEP:GetIronsights()
	return self.Weapon:GetNWBool("Ironsights")
end

SWEP.NextSecondaryAttack = 0
