AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

SWEP.HoldType				= "knife"

if SERVER then
	function SWEP:Shock( attacker, entity, n )
		if entity:IsValid() then
			n = n + 1
			
			local effect = EffectData()
			effect:SetEntity(entity)
			effect:SetMagnitude(5)
			effect:SetScale(4)
			effect:SetRadius(5)
			util.Effect("TeslaHitBoxes", effect)
			
			local dmginfo = DamageInfo()
				dmginfo:SetDamage(math.Rand(1,3))
				dmginfo:SetAttacker( attacker )
				dmginfo:SetInflictor( attacker )
			entity:TakeDamageInfo( dmginfo )
			
			entity:EmitSound("Weapon_StunStick.Activate")
			
			if n <= 7 then
				timer.Simple((math.random(8,20)/100), function() self:Shock( attacker, entity, n ) end )
			end
		end
	end
end