if CLIENT then
	killicon.Add("weapon_shitty_gold_ak", "HUD/killicons/gold_ak", color_white);
end

SWEP.DrawCrosshair = true
SWEP.Weight = 5
SWEP.ViewModel = "models/weapons/cstrike/c_rif_ak47_gold.mdl"
SWEP.WorldModel = "models/weapons/w_rif_ak47_gold.mdl"
SWEP.HoldType = "ar2"
SWEP.ViewModelFOV = 60
SWEP.Slot = 2
SWEP.AutoSwitchTo = true
SWEP.FiresUnderwater = true
SWEP.Spawnable = true
SWEP.AdminSpawnable = true
SWEP.SlotPos = 0
SWEP.AutoSwitchFrom = false
SWEP.base = "weapon_cs_base"
SWEP.Category = "Golden Weapons"
SWEP.DrawAmmo = true
SWEP.PrintName = "Gold AK-47"
SWEP.UseHands = true
SWEP.Icon = "vgui/entities/weapon_shitty_gold_ak"

SWEP.Primary.NumberofShots = 1
SWEP.Primary.Ammo = "SMG1"
SWEP.Primary.Spread = 0.15
SWEP.Primary.ClipSize = 60
SWEP.Primary.Force = 23
SWEP.Primary.Damage = 30
SWEP.Primary.Delay = 0.1
SWEP.Primary.Recoil = 0.1
SWEP.Primary.DefaultClip = 45
SWEP.Primary.Automatic = true
SWEP.Secondary.Automatic = true
SWEP.Primary.TakeAmmo = 1
SWEP.Primary.Sound = Sound("Weapon.GoldAK_Shoot")

SWEP.Secondary.Automatic = false
SWEP.Secondary.Force = 0
SWEP.Secondary.Recoil = 0
SWEP.Secondary.Damage = 0
SWEP.Secondary.Ammo = ""
SWEP.Secondary.NumberofShots = 0
SWEP.Secondary.Spread = 0
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Delay = 1
SWEP.Secondary.Sound = ""
SWEP.Secondary.TakeAmmo = 0
SWEP.Secondary.ClipSize = -1

function SWEP:Deploy()
	self:SendWeaponAnim( ACT_VM_DRAW )
    self:SetNextPrimaryFire(CurTime() + 1)
    self:SetNextSecondaryFire(CurTime() + 1)
	self:SetWeaponHoldType( "ar2" )
   return true
end

function SWEP:Think()

sound.Add({
name = "Weapon.GoldAK_Shoot",

channel = CHAN_STATIC,
volume = .4,
CompatibilityAttenuation = 1.0,
pitch = randompitch,

sound = "weapons/ak47/ak47-1-golden.wav"
})

	
end

function SWEP:Initialize()
	if ( SERVER ) then
	self:SetWeaponHoldType( "ar2" )
	end	
	if ( CLIENT ) then
	self:SetWeaponHoldType( "ar2" )
	end	
end

function SWEP:ShootEffects()
 
	self:SendWeaponAnim( ACT_VM_PRIMARYATTACK )	// View model animation
	self.Owner:SetAnimation( PLAYER_ATTACK1 )		// 3rd Person Animation
 
end

function SWEP:FireAnimationEvent( pos, ang, event, options )

	-- Disables animation based muzzle event
	if ( event == 5001 ) then return true end

end



function SWEP:PrimaryAttack()

	randompitch = math.Rand(99, 100)
	
	if ( !self:CanPrimaryAttack() ) then return end
	local bullet = {}
		bullet.Num = self.Primary.NumberofShots
		bullet.Src = self.Owner:GetShootPos()
		bullet.Dir = self.Owner:GetAimVector()
		bullet.Spread = Vector( self.Primary.Spread * 0.1 , self.Primary.Spread * 0.1, 0)
		bullet.Tracer	= 1
		bullet.TracerName = "Tracer" 
		bullet.Force = self.Primary.Force
		bullet.Damage = self.Primary.Damage
		bullet.AmmoType = self.Primary.Ammo
	local rnda = self.Primary.Recoil * 0.5
	local rndb = self.Primary.Recoil * math.random(-2, 2)
	self:ShootEffects()
	self:MuzFlash()
	self.Owner:FireBullets( bullet )
	self.Weapon:EmitSound(Sound(self.Primary.Sound))
	self.Owner:ViewPunch( Angle( rnda,rndb,rnda ) )
	self:TakePrimaryAmmo(self.Primary.TakeAmmo)
	self.Weapon:SetNextPrimaryFire( CurTime() + self.Primary.Delay )
	self.Weapon:SetNextSecondaryFire( CurTime() + self.Primary.Delay )
end

function SWEP:MuzFlash(modelindex)
	modelindex = modelindex or 0
	if !IsFirstTimePredicted() or !IsValid(self.Owner) or self.Owner:WaterLevel() == 3 then return end
	local fx = EffectData()
	fx:SetEntity(self)
	fx:SetSurfaceProp(modelindex)
	fx:SetOrigin(self.Owner:GetShootPos())
	fx:SetNormal(self.Owner:GetAimVector())
	fx:SetAttachment(1)
	util.Effect("muzzle_eff", fx) 
	if !game.SinglePlayer() and CLIENT or game.SinglePlayer() then
		self.Owner:MuzzleFlash()
	end
end

function SWEP:SecondaryAttack()
end

function SWEP:Reload()
 //if self.ReloadingTime and CurTime() <= self.ReloadingTime then return end
 
	if ( self:Clip1() < self.Primary.ClipSize and self.Owner:GetAmmoCount( self.Primary.Ammo ) > 0 ) then
	
		self:DefaultReload( ACT_VM_RELOAD )
	end
end