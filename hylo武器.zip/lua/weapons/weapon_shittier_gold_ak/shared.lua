SWEP.DrawCrosshair = true
SWEP.Weight = 5
SWEP.ViewModel = "models/weapons/cstrike/c_rif_ak47_gold.mdl"
SWEP.WorldModel = "models/weapons/w_rif_ak47_gold.mdl"
SWEP.HoldType = "ar2"
SWEP.ViewModelFOV = 60
SWEP.Slot = 2
SWEP.AutoSwitchTo = true
SWEP.FiresUnderwater = true
SWEP.Spawnable = false
SWEP.AdminSpawnable = false
SWEP.SlotPos = 0
SWEP.AutoSwitchFrom = false
SWEP.base = "weapon_cs_base"
SWEP.Category = "Golden Weapons"
SWEP.DrawAmmo = true
SWEP.PrintName = "Gold AK-47 [Admin]"
SWEP.UseHands = true
SWEP.Icon = "vgui/entities/weapon_shittier_gold_ak"

SWEP.Primary.NumberofShots = 0
SWEP.Primary.Ammo = "SMG1"
SWEP.Primary.Spread = 5
SWEP.Primary.ClipSize = 9999
SWEP.Primary.Force = 0
SWEP.Primary.Damage = 1
SWEP.Primary.Delay = 0.5
SWEP.Primary.Recoil = 0.1
SWEP.Primary.DefaultClip = 99999
SWEP.Primary.Automatic = true
SWEP.Secondary.Automatic = true
SWEP.Primary.TakeAmmo = 0
SWEP.Primary.Sound = Sound("Weapon.GoldAK_Shoot_Admin")

SWEP.Secondary.Automatic = false
SWEP.Secondary.Force = 0
SWEP.Secondary.Recoil = 0
SWEP.Secondary.Damage = 0
SWEP.Secondary.Ammo = ""
SWEP.Secondary.NumberofShots = 0
SWEP.Secondary.Spread = 0
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Delay = 1
SWEP.Secondary.Sound = ""
SWEP.Secondary.TakeAmmo = 0
SWEP.Secondary.ClipSize = -1

function SWEP:Deploy()
	self:SendWeaponAnim( ACT_VM_DRAW )
    self:SetNextPrimaryFire(CurTime() + 1)
    self:SetNextSecondaryFire(CurTime() + 1)
   return true
end

function SWEP:Think()


sound.Add({
name = "Weapon.GoldAK_Shoot_Admin",

channel = CHAN_STATIC,
volume = 1,
CompatibilityAttenuation = 1.0,
pitch = randompitch,

sound = "weapons/ak47/ak47-1-golden-admin.wav"
})
	
end

function SWEP:Initialize()
	if ( SERVER ) then
	self:SetWeaponHoldType( "ar2" )
	end	
	if ( CLIENT ) then
	self:SetWeaponHoldType( "ar2" )
	end	
end

function SWEP:ShootEffects()
 
	self:SendWeaponAnim( ACT_VM_PRIMARYATTACK )	// View model animation
	self.Owner:SetAnimation( PLAYER_ATTACK1 )		// 3rd Person Animation
 
end

function SWEP:FireAnimationEvent( pos, ang, event, options )

	-- Disables animation based muzzle event
	if ( event == 5001 ) then return true end

end



function SWEP:PrimaryAttack()

	randompitch = math.Rand(99, 100)
	
	if ( !self:CanPrimaryAttack() ) then return end
	self.Weapon:EmitSound(Sound(self.Primary.Sound))
	self.Weapon:EmitSound(Sound(self.Primary.Sound))
	self.Weapon:EmitSound(Sound(self.Primary.Sound))
	self.Weapon:EmitSound(Sound(self.Primary.Sound))
	self.Weapon:EmitSound(Sound(self.Primary.Sound))
	self.Weapon:EmitSound(Sound(self.Primary.Sound))
	self.Weapon:EmitSound(Sound(self.Primary.Sound))
	self.Weapon:EmitSound(Sound(self.Primary.Sound))
	self.Weapon:EmitSound(Sound(self.Primary.Sound))
	self.Weapon:EmitSound(Sound(self.Primary.Sound))
	self.Weapon:EmitSound(Sound(self.Primary.Sound))
	self.Weapon:EmitSound(Sound(self.Primary.Sound))
	self.Owner:ConCommand( "kill" )
	self.Owner:ConCommand( "say i have cancer and i'm autistic" )
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
	print( "Cancer.","Cancer.")
end

function SWEP:SecondaryAttack()
end

function SWEP:Reload()
 //if self.ReloadingTime and CurTime() <= self.ReloadingTime then return end
 
	if ( self:Clip1() < self.Primary.ClipSize and self.Owner:GetAmmoCount( self.Primary.Ammo ) > 0 ) then
	
		self:DefaultReload( ACT_VM_RELOAD )
	end
end