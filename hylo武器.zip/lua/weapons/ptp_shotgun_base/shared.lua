if ( SERVER ) then

	AddCSLuaFile( "shared.lua" )
	
end

if ( CLIENT ) then

	SWEP.PrintName			= "Shotteh"			
	SWEP.Author				= "Fonix"
	SWEP.Slot				= 3
	SWEP.SlotPos			= 1
	SWEP.IconLetter			= ""
	SWEP.IconLetterCSS		= ""
	
	killicon.AddFont( "weapon_cs_ak47", "TextKillIcons", SWEP.IconLetter, Color( 255, 80, 0, 255 ) )
	surface.CreateFont("TextKillIcons", { font="Roboto-Medium", weight="500", size=ScreenScale(13),antialiasing=true,additive=true })
	surface.CreateFont("TextSelectIcons", { font="Roboto-Medium", weight="500", size=ScreenScale(20),antialiasing=true,additive=true })
	surface.CreateFont("CSKillIcons", { font="csd", weight="500", size=ScreenScale(30),antialiasing=true,additive=true })
	surface.CreateFont("CSSelectIcons", { font="csd", weight="500", size=ScreenScale(60),antialiasing=true,additive=true })
end


SWEP.HoldType			= "shotgun"
SWEP.Base				= "ptp_weapon_base"
SWEP.Category			= "PTP: Heavy"

SWEP.Spawnable			= false
SWEP.AdminSpawnable		= false

SWEP.ViewModel			= "models/weapons/v_shot_war_md.mdl"
SWEP.WorldModel			= "models/weapons/w_shot_war_md.mdl"
SWEP.ViewModelFlip		= true
SWEP.ViewModelFOV		= 70

SWEP.Weight				= 5
SWEP.AutoSwitchTo		= true
SWEP.AutoSwitchFrom		= true

SWEP.Primary.Sound			= Sound( "sound_fire.single" )
SWEP.Primary.Recoil			= 4
SWEP.Primary.Damage			= 15
SWEP.Primary.NumShots		= 10
SWEP.Primary.Cone			= 0.05
SWEP.Primary.ClipSize		= 8
SWEP.Primary.Delay			= 0.3
SWEP.Primary.DefaultClip	= 64
SWEP.Primary.Automatic		= false
SWEP.Primary.Ammo			= "buckshot"

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"

SWEP.IronSightsPos 		= Vector( 2.03, -5, 0.7 )
SWEP.IronSightsAng 		= Vector( 0, 0, 0 )

--Extras
SWEP.MuzzleEffect			= "lee_muzzle_rifle"
SWEP.MuzzleAttachment			= "1"
SWEP.MuzzleAttachmentTrue		= true
SWEP.TracerShot				= 3
SWEP.BulletForce			= 100
SWEP.Silenceable			= false
SWEP.SilenceTiming			= 2
SWEP.ZoomFOV				= 65
SWEP.CSSZoom				= false
SWEP.ShellTime			= 0.5

-- Accuracy
SWEP.Delay				= 0.4	-- Delay For Not Zoom
SWEP.Recoil				= 4	-- Recoil For not Aimed
SWEP.RecoilZoom				= 0.3	-- Recoil For Zoom

/*---------------------------------------------------------
	PrimaryAttack
---------------------------------------------------------*/
function SWEP:PrimaryAttack()	

	local DisableDashing = false
	
		if GetConVar("sv_ptp_dashing_disable") == nil then
		DisableDashing = false
		else
		DisableDashing = GetConVar("sv_ptp_dashing_disable"):GetBool()
		end
		
	if self.Owner:KeyPressed(IN_ATTACK) and self.Owner:KeyDown(IN_RELOAD) then return end 
	
	if self.Owner:KeyDown(IN_SPEED) and not DisableDashing then return end

	

	self.Weapon:SetNextPrimaryFire( CurTime() + self.Primary.Delay )
	
	if ( !self:CanPrimaryAttack() ) then return end
	// If Swep Data is Silenced Play Silenced else Unsilenced
	if self.Weapon:GetNetworkedBool("Silenced") == true then
		self.Weapon:EmitSound( self.SilencedSound )
		self:CSShootBullet( self.Primary.Damage, self.Primary.Recoil, self.Primary.NumShots, self.Primary.Cone )
	else	
		self.Weapon:EmitSound( self.Primary.Sound )
		self:CSShootBullet( self.Primary.Damage, self.Primary.Recoil, self.Primary.NumShots, self.Primary.Cone )
	end
	
	// Remove 1 bullet from our clip
	self:TakePrimaryAmmo( self.TakeAmmoOnShot )
	
	if ( self.Owner:IsNPC() ) then return end
	
	// Punch the player's view
	self.Owner:ViewPunch( Angle( math.Rand(-0.2,-0.1) * self.Primary.Recoil * 10, math.Rand(-0.1,0.1) *self.Primary.Recoil, 0 ) )
	
	// In singleplayer this function doesn't get called on the client, so we use a networked float
	// to send the last shoot time. In multiplayer this is predicted clientside so we don't need to 
	// send the float.
	if ( (game.SinglePlayer() && SERVER) || CLIENT ) then
		self.Weapon:SetNetworkedFloat( "LastShootTime", CurTime() )
	end
	
end
/*---------------------------------------------------------
	Reload does nothing
---------------------------------------------------------*/
function SWEP:Reload()
	
	//if ( CLIENT ) then return end
		
		self:SetIronsights(false)
	//Set the ironsight mode to false
	
		if ( self.Weapon:Clip1() < 1) and self.Owner:KeyPressed(IN_ATTACK) or ( self.Weapon:Clip1() == self.Primary.ClipSize )then return end
		
		
		self.Owner:SetFOV(0, 0.15)
		self.Primary.Recoil = self:GetNWInt("recoil")
	
	// Already reloading
	if ( self.Weapon:GetNetworkedBool( "reloading", false ) ) then return end
	

	
	// Start reloading if we can
	if ( self.Weapon:Clip1() < self.Primary.ClipSize && self.Owner:GetAmmoCount( self.Primary.Ammo ) > 0 ) then
		
		self.Weapon:SendWeaponAnim(ACT_SHOTGUN_RELOAD_START)

		if (game.SinglePlayer() ) then
		timer.Simple( 0.5, function()
		self.Weapon:SetNetworkedBool( "reloading", true )
		self.Weapon:SetVar( "reloadtimer", CurTime() + self.ShellTime  )
		end)
		else
		self.Weapon:SetNetworkedBool( "reloading", true )
		end
		
	end
end

/*---------------------------------------------------------
   Think does nothing
---------------------------------------------------------*/
function SWEP:Think()

	self:ShottyReload()
	
	self:DashingPos() //Dont to be confused with doshing 
	
	--Recoil on Zoom/UnZoomed
	if self.Weapon:GetNetworkedBool( "Ironsights" ) then
		self.Primary.Recoil = self:GetNWInt("recoilzoom")
	else
		self.Primary.Recoil = self:GetNWInt("recoil")
	end
	
	local DisableDashing = false		//Garanties on disable that ironsights stay the aimsights
	
		if GetConVar("sv_ptp_dashing_disable") == nil then
		DisableDashing = false
		else
		DisableDashing = GetConVar("sv_ptp_dashing_disable"):GetBool()
		end
	
	if DisableDashing then 
	self.IronSightsPos = self.AimSightsPos
	self.IronSightsAng = self.AimSightsAng
	end
	
	if self.Owner:KeyPressed(IN_SPEED) or self.Owner:KeyPressed(IN_JUMP) and not self.Owner:KeyDown(IN_SPEED) then
	self.Weapon:SetNetworkedBool("Ironsights", false)
	self.Owner:SetFOV(0, 0.15)
	self.Primary.Recoil = self:GetNWInt("recoil")
	end
end

/*---------------------------------------------------------
Shotty Reload
---------------------------------------------------------*/
function SWEP:ShottyReload()

		
		if self.Owner:KeyPressed(IN_ATTACK) then 
			self.Weapon:SetNetworkedBool( "reloading", false )
		end
	
	if ( self.Weapon:GetNetworkedBool( "reloading", false ) ) then
	
		if ( self.Weapon:GetVar( "reloadtimer", 0 ) < CurTime()) then
			
			// Finsished reload 
			if ( self.Weapon:Clip1() >= self.Primary.ClipSize || self.Owner:GetAmmoCount( self.Primary.Ammo ) <= 0 ) then
				self.Weapon:SetNetworkedBool( "reloading", false )
				return
			end
			
			self.Weapon:SetVar( "reloadtimer", CurTime() + self.ShellTime )
			if not ( self.Weapon:Clip1() == self.Primary.ClipSize) then 
			self.Weapon:SendWeaponAnim( ACT_VM_RELOAD )
			end
			
			// Add ammo
			self.Owner:RemoveAmmo( 1, self.Primary.Ammo, false )
			self.Weapon:SetClip1(  self.Weapon:Clip1() + 1 )
			
			// Finish filling, final pump. Current Clip is = to ClipSize or No more ammo in the reserve
			if ( self.Weapon:Clip1() == self.Primary.ClipSize || self.Owner:GetAmmoCount( self.Primary.Ammo ) <= 0) then
				self.Weapon:SetNetworkedBool( "reloading", false )
				self.Weapon:SetNextPrimaryFire(CurTime() + self.Primary.Delay)
				timer.Simple( 0.5, function() 
					if self.Weapon == nil then return end
					self.Weapon:SendWeaponAnim( ACT_SHOTGUN_RELOAD_FINISH )
					self.Weapon:SetNextPrimaryFire(CurTime() + self.Primary.Delay)
			end ) 
			
		end
	end
end
end
/*---------------------------------------------------------
DashingPos
---------------------------------------------------------*/
function SWEP:DashingPos()

		
		local DisableDashing = false
	
		if GetConVar("sv_ptp_dashing_disable") == nil then
		DisableDashing = false
		else
		DisableDashing = GetConVar("sv_ptp_dashing_disable"):GetBool()
		end
	
	if DisableDashing then return end
	
		if self.Owner:KeyDown(IN_SPEED) then 
			self.IronSightsPos	= self.DashArmPos
			self.IronSightsAng	= self.DashArmAng
			self.Weapon:SetNetworkedBool("Ironsights", true)
			self.SwayScale 	= 1.0
			self.BobScale 	= 1.0
			if not (self.Pistol) then
			self:SetWeaponHoldType("passive") 
			else
			self:SetWeaponHoldType("normal")
			end 
		end
		
		if self.Owner:KeyReleased(IN_SPEED) then
			self.Weapon:SetNextPrimaryFire( CurTime() + 0.2 )
			self.Weapon:SetNetworkedBool("Ironsights", false)
			self:SetWeaponHoldType( self.HoldType )
		end
		
		if self.Owner:KeyDown(IN_SPEED) then return end
		
		if self.Owner:KeyPressed(IN_ATTACK2) then
		self.IronSightsPos = self.AimSightsPos
		self.IronSightsAng = self.AimSightsAng
		end
end