--aK47

sound.Add({
	name = 			"TFA_CSGO_AK47.1",
	channel = 		CHAN_USER_BASE+10,
	volume = 		1.0,
	sound = 			"weapons/tfa_csgo/ak47/ak47-1.wav"
})

sound.Add({
	name = 			"TFA_CSGO_AK47.Clipout",
	channel = 		CHAN_USER_BASE+11,
	volume = 		1.0,
	sound = 			"weapons/tfa_csgo/ak47/ak47_clipout.wav"
})

sound.Add({
	name = 			"TFA_CSGO_AK47.Clipin",
	channel = 		CHAN_USER_BASE+11,
	volume = 		1.0,
	sound = 			"weapons/tfa_csgo/ak47/ak47_clipin.wav"
})

sound.Add({
	name = 			"TFA_CSGO_AK47.BoltPull",
	channel = 		CHAN_USER_BASE+11,
	volume = 		1.0,
	sound = 			"weapons/tfa_csgo/ak47/ak47_boltpull.wav"
})

sound.Add({
	name = 			"TFA_CSGO_AK47.Draw",
	channel = 		CHAN_USER_BASE+11,
	volume = 		1.0,
	sound = 			"weapons/tfa_csgo/ak47/ak47_draw.wav"
})



if ( CLIENT ) then

	SWEP.PrintName			= "AK-47 | Phoenix"			
	SWEP.Author				= "Snackorino // PeridotPower"
	SWEP.Slot				= 2
	SWEP.SlotPos			= 1
	SWEP.IconLetterCSS		= "b"
	
	killicon.AddFont( "weapon_ak47_csgo", "CSKillIcons", SWEP.IconLetterCSS, Color( 255, 255, 255, 255 ) )
	
end

SWEP.HoldType			= "ar2"
SWEP.Base				= "ptp_weapon_base"
SWEP.Category			= "AK-47 Phoenix"

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= true
SWEP.ViewModelFlip		= true
SWEP.ViewModel			= "models/weapons/v_pho_ak47.mdl"
SWEP.WorldModel			= "models/weapons/w_pho_ak47.mdl"
SWEP.UseHands			= true
SWEP.ViewModelFOV		= 50

SWEP.Weight				= 5
SWEP.AutoSwitchTo		= false
SWEP.AutoSwitchFrom		= false

SWEP.Primary.Sound			= Sound( "TFA_CSGO_AK47.1" )
SWEP.Primary.Recoil			= 0
SWEP.Primary.Damage			= 37
SWEP.Primary.NumShots		= 1
SWEP.Primary.Cone			= 0.02
SWEP.Primary.ClipSize		= 30
SWEP.Primary.Delay			= 0.1
SWEP.Primary.DefaultClip	= 480
SWEP.Primary.Automatic		= true
SWEP.Primary.Ammo			= "smg1"

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"

SWEP.AimSightsPos = Vector(2.3, -5.643, 0.92)
SWEP.DashArmPos = Vector(12.119, 0, -1.68)
SWEP.AimSightsAng = Vector(2.675	, 0, -1.407)
SWEP.DashArmAng = Vector(-7.6, 27.399, 0)


-- Accuracy
SWEP.CrouchCone				= 0.01 -- Accuracy when we're crouching
SWEP.CrouchWalkCone			= 0.02 -- Accuracy when we're crouching and walking
SWEP.WalkCone				= 0.025 -- Accuracy when we're walking
SWEP.AirCone				= 0.1 -- Accuracy when we're in air
SWEP.StandCone				= 0.015 -- Accuracy when we're standing still
SWEP.Delay				= 0.1
SWEP.Recoil				= 0
SWEP.RecoilZoom			= 0
SWEP.ShellDelay	        = 0.05

SWEP.Pos = nil
SWEP.Ang = nil

SWEP.Offset = {
	Pos = {
		Up = 0.6,
		Right = 0.5,
		Forward = 1,
	},
	Ang = {
		Up = -2,
		Right = 6,
		Forward = 352,
	}
}

function SWEP:DrawWorldModel( )
	local hand, offset
	
	if not IsValid( self.Owner ) then
		self:DrawModel( )
		return
	end
	
	if not self.Hand then
		self.Hand = self.Owner:LookupAttachment( "anim_attachment_rh" )
	end
	
	hand = self.Owner:GetAttachment( self.Hand )
	
	if not hand then
		self:DrawModel( )
		return
	end

	offset = hand.Ang:Right( ) * self.Offset.Pos.Right + hand.Ang:Forward( ) * self.Offset.Pos.Forward + hand.Ang:Up( ) * self.Offset.Pos.Up
	
	hand.Ang:RotateAroundAxis( hand.Ang:Right( ), self.Offset.Ang.Right )
	hand.Ang:RotateAroundAxis( hand.Ang:Forward( ), self.Offset.Ang.Forward )
	hand.Ang:RotateAroundAxis( hand.Ang:Up( ), self.Offset.Ang.Up )
	
	self:SetRenderOrigin( hand.Pos + offset )
	self:SetRenderAngles( hand.Ang )
	
	self:DrawModel( )
end