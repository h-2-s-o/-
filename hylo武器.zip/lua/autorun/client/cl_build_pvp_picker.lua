if !CLIENT then return end  

//	Build/PVP picker thingy. By Hackcraft http://steamcommunity.com/profiles/76561198061694551/

--> Console command

concommand.Add("bp_picker_menu", function()
	-- Putting it in here as it won't be opened often and it's easier for screen res
	local xScreenRes = 1920
	local yScreenRes = 1080
	local wMod = ScrW() / xScreenRes     
	local hMod = ScrH() / yScreenRes

	surface.CreateFont( "bp_SmoothBig", { font = "Trebuchet18", size = wMod*34, weight = 700, antialias = true } ) 


    local Frame = vgui.Create( "DFrame" )
	Frame:SetSize( wMod*240, hMod*130 )
	Frame:Center()
	Frame:SetTitle("")
	Frame:SetVisible( true )
	Frame:SetDraggable( false )
	Frame:ShowCloseButton( false )
	Frame:MakePopup()
	Frame.Paint = function( self, w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color( 44, 91, 255, 250 ) ) -- Draw a blue button
	end

	local Button = vgui.Create( "DButton", Frame )
	Button:SetText( "Build mode" )
	Button:SetFont("bp_SmoothBig")
	Button:SetTextColor( Color( 255, 255, 255 ) )
	Button:SetPos( wMod*20, hMod*20 )
	Button:SetSize( wMod*200, hMod*30 )
	Button.Paint = function( self, w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 63, 255, 250 ) ) -- Draw a blue button
	end
	Button.DoClick = function()
		Frame:Remove()
		RunConsoleCommand("bp_picker_build")
	end

	local Button = vgui.Create( "DButton", Frame )
	Button:SetText( "PvP mode" )
	Button:SetFont("bp_SmoothBig")
	Button:SetTextColor( Color( 255, 255, 255 ) )
	Button:SetPos( wMod*20, hMod*80 )
	Button:SetSize( wMod*200, hMod*30 )
	Button.Paint = function( self, w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 63, 255, 250 ) ) -- Draw a blue button
	end
	Button.DoClick = function()
		Frame:Remove()
		RunConsoleCommand("bp_picker_pvp")
	end
end)
