player_manager.AddValidModel( "Yuuka Kazami", 				"models/player/Yuuka.mdl" )
player_manager.AddValidHands( "Yuuka Kazami", "models/player/yuuka_hands.mdl" , 0, "00000000" )
list.Set( "PlayerOptionsModel",  "Yuuka Kazami",				"models/player/Yuuka.mdl" )
