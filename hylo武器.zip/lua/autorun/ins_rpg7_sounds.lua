sound.Add(
{
name = "Weapon_INS_RPG7.Single",
channel = CHAN_WEAPON,
volume = 1,
level = 75,
pitch = { 90, 100 },
sound = "ins/weapons/rpg7/rpg7-fire.wav"
} )
sound.Add(
{
name = "Weapon_INS_RPG7.Echo",
channel = CHAN_STATIC,
volume = 1,
level = 140,
pitch = { 90, 100 },
sound = "ins/weapons/rpg7/rpg7-fire_echo.wav"
} )
sound.Add(
{
name = "Weapon_INS_RPG7.Empty",
channel = CHAN_ITEM,
volume = 1,
level = 75,
sound = "ins/weapons/rpg7/rpg7-empty.wav"
} )
sound.Add(
{
name = "Weapon_INS_RPG7.Reload",
channel = CHAN_ITEM,
volume = 1,
level = 75,
sound = "ins/weapons/rpg7/rpg7-reload.wav"
} )
sound.Add(
{
name = "Weapon_INS_RPG7.Load",
channel = CHAN_ITEM,
volume = 1,
level = 75,
sound = "ins/weapons/rpg7/rpg7-load.wav"
} )
sound.Add(
{
name = "Weapon_INS_RPG7.Unload",
channel = CHAN_ITEM,
volume = 1,
level = 75,
sound = "ins/weapons/rpg7/rpg7-unload.wav"
} )