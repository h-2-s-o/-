/*---------------------------------------------------------
 Textures
---------------------------------------------------------*/
resource.AddFile( "materials/scope/scope_normal.vmt" );
resource.AddFile( "materials/scope/scope_normal.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_cs_ak47.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_cs_ak47.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_cs_aug.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_cs_aug.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_cs_autoshotgun.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_cs_autoshotgun.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_cs_awp.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_cs_awp.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_cs_deagle.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_cs_deagle.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_cs_elites.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_cs_elites.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_cs_famas.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_cs_famas.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_cs_fiveseven.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_cs_fiveseven.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_weapon_flash.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_weapon_flash.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_cs_g3sg1.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_cs_g3sg1.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_cs_galil.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_cs_galil.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_cs_glock.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_cs_glock.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_weapon_grenade.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_weapon_grenade.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_cs_knife.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_cs_knife.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_cs_m4.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_cs_m4.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_cs_mac10.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_cs_mac10.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_cs_mp5.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_cs_mp5.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_cs_p90.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_cs_p90.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_cs_p228.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_cs_p228.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_cs_para.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_cs_para.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_cs_pumpshotgun.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_cs_pumpshotgun.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_cs_scout.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_cs_scout.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_cs_sg550.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_cs_sg550.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_cs_sg552.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_cs_sg552.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_weapon_smoke.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_weapon_smoke.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_cs_tmp.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_cs_tmp.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_cs_ump45.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_cs_ump45.vtf" );

resource.AddFile( "materials/vgui/entities/ptp_cs_usp.vmt" );
resource.AddFile( "materials/vgui/entities/ptp_cs_usp.vtf" );

resource.AddFile( "sound/weapons/universal/iron_in.wav" );
resource.AddFile( "sound/weapons/universal/iron_out.wav" );

