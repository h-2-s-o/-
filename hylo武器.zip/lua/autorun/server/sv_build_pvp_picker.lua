if !SERVER then return end 

print("Loading the server side of build and pvp mode picker!")

//	Build/PVP picker thingy. By Hackcraft http://steamcommunity.com/profiles/76561198061694551/

--> Variables
local CoolDown = 10 -- seconds

--> Tables
local Builders = {}
local CoolDowns = {} 
 
--> Functions
local States = {}
States["build"] = function(ply) 
	Builders[ply] = true 
	ply:GodEnable()
	ply:ChatPrint("You have entered build mode!")
end
States["pvp"] = function(ply) 
	Builders[ply] = nil 
	ply:GodDisable()
	ply:ChatPrint("You have entered PvP mode!")
	-- Stop players from keeping noclip when they change!
	if ply:GetMoveType() == MOVETYPE_NOCLIP then ply:SetMoveType(MOVETYPE_WALK) end
end

local function ChangeState(ply, newState)
	if States[newState] != nil then
		-- Anti-spam
		if CoolDowns[ply] != nil and CoolDowns[ply] + CoolDown > CurTime() then 
			ply:ChatPrint("Please wait " .. math.Round((CoolDowns[ply]+CoolDown) - CurTime()) .. " seconds before changing to " .. newState) 
			return 
		end
		CoolDowns[ply] = CurTime()
		-- Run the specific function to set the mode
		States[newState](ply)
	end
end

--> Console commands
concommand.Add("bp_picker_build", function(ply)
    ChangeState(ply, "build")
end)

concommand.Add("bp_picker_pvp", function(ply)
    ChangeState(ply, "pvp")
end)

--> Hooks
hook.Add("PlayerNoClip", "bp_picker", function(ply, desiredNoClipState)
	if desiredNoClipState then
		-- Only let builders noclip!
		return Builders[ply] != nil
	else
		-- Let them leave noclip
		return true
	end
end)

hook.Add("PlayerInitialSpawn", "bp_picker", function(ply)
	-- Put them in build mode to start with incase they skip the menu check
	Builders[ply] = true 
	ply:GodEnable()
	-- Open the menu on the client
	ply:ConCommand("bp_picker_menu")
end)

hook.Add("PlayerSay", "bp_picker", function(ply, text, public)
	text = string.lower( text ) -- Make the chat message entirely lowercase
	if string.Left(text, 1) == "!" then text = string.TrimLeft(text, "!") else return end
	if States[text] != nil then
		ChangeState(ply, text)
	end
end)

hook.Add("PlayerShouldTakeDamage", "bp_damageblock", function(ply, attacker)
	if Builders[attacker] != nil then
		return false
	end
end)