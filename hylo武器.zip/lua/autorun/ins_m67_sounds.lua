sound.Add(
{
name = "Weapon_INS_M67.Pin",
channel = CHAN_ITEM,
volume = 1,
level = 70,
sound = "ins/weapons/m67/pullpin.wav"
} )
sound.Add(
{
name = "Weapon_INS_M67.Spoon",
channel = CHAN_ITEM,
volume = 1,
level = 70,
sound = "ins/weapons/m67/spoon.wav"
} )
sound.Add(
{
name = "Weapon_INS_M67.Throw",
channel = CHAN_ITEM,
volume = 1,
level = 70,
sound = "ins/weapons/m67/throw.wav"
} )
sound.Add(
{
name = "Grenade_INS.Bounce",
channel = CHAN_ITEM,
volume = 0.7,
level = 75,
sound = { "ins/weapons/m67/roll1.wav",
"ins/weapons/m67/roll2.wav",
"ins/weapons/m67/roll3.wav",
"ins/weapons/m67/roll4.wav",
"ins/weapons/m67/roll5.wav",
"ins/weapons/m67/roll6.wav" }
} )