sound.Add(
{
name = "Universal_INS.IronIn",
channel = CHAN_ITEM,
volume = 0.7,
level = 75,
pitch = { 95, 100 },
sound = "ins/weapons/universal/uni-ironin.wav"
} )
sound.Add(
{
name = "Universal_INS.IronOut",
channel = CHAN_ITEM,
volume = 0.7,
level = 75,
pitch = { 95, 100 },
sound = "ins/weapons/universal/uni-ironout.wav"
} )
sound.Add(
{
name = "Universal_INS.Draw",
channel = CHAN_ITEM,
volume = 0.7,
level = 75,
pitch = { 95, 108 },
sound = "ins/weapons/universal/uni-draw.wav"
} )