--[[BEACON.Name = "<empty>"

function BEACON:FindFunction( entities, myTrashTable )
	return myTrashTable
end

function BEACON:DrawFunction( ent )

	return false
end
]]